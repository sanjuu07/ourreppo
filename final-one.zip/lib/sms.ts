import twilio from "twilio"
import { sql } from "./db"

// Twilio configuration
const accountSid = process.env.TWILIO_ACCOUNT_SID
const authToken = process.env.TWILIO_AUTH_TOKEN
const twilioPhoneNumber = process.env.TWILIO_PHONE_NUMBER

let twilioClient: twilio.Twilio | null = null

if (accountSid && authToken) {
  twilioClient = twilio(accountSid, authToken)
}

export interface SMSMessage {
  to: string
  message: string
  studentId: string
  teacherId: string
}

export async function sendSMS(smsData: SMSMessage): Promise<{
  success: boolean
  messageId?: string
  error?: string
}> {
  try {
    // Log SMS attempt
    const [logEntry] = await sql`
      INSERT INTO sms_logs (student_id, teacher_id, phone_number, message, status)
      VALUES (${smsData.studentId}, ${smsData.teacherId}, ${smsData.to}, ${smsData.message}, 'pending')
      RETURNING id
    `

    if (!twilioClient || !twilioPhoneNumber) {
      // Simulate SMS sending for demo
      console.log(`📱 SMS Simulation - To: ${smsData.to}, Message: ${smsData.message}`)

      // Update log as sent
      await sql`
        UPDATE sms_logs 
        SET status = 'sent', sent_at = NOW(), provider_message_id = 'demo-' || ${logEntry.id}
        WHERE id = ${logEntry.id}
      `

      return {
        success: true,
        messageId: `demo-${logEntry.id}`,
      }
    }

    // Send actual SMS via Twilio
    const message = await twilioClient.messages.create({
      body: smsData.message,
      from: twilioPhoneNumber,
      to: smsData.to,
    })

    // Update log as sent
    await sql`
      UPDATE sms_logs 
      SET status = 'sent', sent_at = NOW(), provider_message_id = ${message.sid}
      WHERE id = ${logEntry.id}
    `

    return {
      success: true,
      messageId: message.sid,
    }
  } catch (error: any) {
    console.error("SMS sending failed:", error)

    // Update log as failed
    await sql`
      UPDATE sms_logs 
      SET status = 'failed', error_message = ${error.message}
      WHERE student_id = ${smsData.studentId} 
      AND phone_number = ${smsData.to}
      AND status = 'pending'
      ORDER BY created_at DESC
      LIMIT 1
    `

    return {
      success: false,
      error: error.message,
    }
  }
}

export async function sendBulkAbsenteesSMS(
  absentees: {
    studentId: string
    studentName: string
    parentPhone: string
    className: string
    teacherId: string
    date: string
    period: number
  }[],
): Promise<{
  sent: number
  failed: number
  results: Array<{ studentId: string; success: boolean; error?: string }>
}> {
  const results = []
  let sent = 0
  let failed = 0

  for (const absentee of absentees) {
    if (!absentee.parentPhone) {
      results.push({
        studentId: absentee.studentId,
        success: false,
        error: "No phone number available",
      })
      failed++
      continue
    }

    const message = `Dear Parent, ${absentee.studentName} from ${absentee.className} was absent in Period ${absentee.period} on ${absentee.date}. Please contact school if needed. - Greenwood School`

    const result = await sendSMS({
      to: absentee.parentPhone,
      message,
      studentId: absentee.studentId,
      teacherId: absentee.teacherId,
    })

    results.push({
      studentId: absentee.studentId,
      success: result.success,
      error: result.error,
    })

    if (result.success) {
      sent++
    } else {
      failed++
    }

    // Small delay to avoid rate limiting
    await new Promise((resolve) => setTimeout(resolve, 100))
  }

  return { sent, failed, results }
}

// Webhook handler for Twilio delivery status
export async function handleSMSWebhook(data: {
  MessageSid: string
  MessageStatus: string
  ErrorCode?: string
  ErrorMessage?: string
}) {
  try {
    const status =
      data.MessageStatus === "delivered" ? "delivered" : data.MessageStatus === "failed" ? "failed" : "sent"

    await sql`
      UPDATE sms_logs 
      SET status = ${status}, 
          delivered_at = ${status === "delivered" ? "NOW()" : null},
          error_message = ${data.ErrorMessage || null}
      WHERE provider_message_id = ${data.MessageSid}
    `

    console.log(`SMS status updated: ${data.MessageSid} -> ${status}`)
  } catch (error) {
    console.error("Failed to update SMS status:", error)
  }
}
