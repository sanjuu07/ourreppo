export interface Teacher {
  id: string
  email: string
  name: string
  phone?: string
  role: "teacher" | "admin"
  department?: string
  created_at: string
  updated_at: string
}

export interface Class {
  id: string
  name: string
  grade: string
  section?: string
  teacher_id: string
  academic_year: string
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface Student {
  id: string
  roll_no: number
  name: string
  class_id: string
  parent_name?: string
  parent_phone?: string
  parent_email?: string
  address?: string
  date_of_birth?: string
  gender?: "male" | "female" | "other"
  blood_group?: string
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface AttendanceRecord {
  id: string
  student_id: string
  class_id: string
  teacher_id: string
  date: string
  period: number
  subject?: string
  is_present: boolean
  marked_at: string
  notes?: string
  sms_sent: boolean
  sms_sent_at?: string
  created_at: string
  updated_at: string
}

export interface Schedule {
  id: string
  class_id: string
  period: number
  subject: string
  start_time: string
  end_time: string
  day_of_week: number // 0 = Sunday, 1 = Monday, etc.
  teacher_id: string
  room_number?: string
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface SMSLog {
  id: string
  student_id: string
  teacher_id: string
  phone_number: string
  message: string
  status: "pending" | "sent" | "failed" | "delivered"
  provider: "twilio" | "other"
  provider_message_id?: string
  error_message?: string
  sent_at?: string
  delivered_at?: string
  created_at: string
  updated_at: string
}

export interface AuditLog {
  id: string
  user_id: string
  user_type: "teacher" | "admin"
  action: string
  resource_type: string
  resource_id?: string
  old_values?: Record<string, any>
  new_values?: Record<string, any>
  ip_address?: string
  user_agent?: string
  created_at: string
}

// API Response types
export interface ApiResponse<T = any> {
  success: boolean
  data?: T
  error?: string
  message?: string
}

export interface PaginatedResponse<T> extends ApiResponse<T[]> {
  pagination: {
    page: number
    limit: number
    total: number
    totalPages: number
  }
}

// Dashboard types
export interface DashboardStats {
  presentToday: number
  absentToday: number
  totalStudents: number
  totalClasses: number
  attendanceRate: number
  smssSentToday: number
  nextPeriod?: {
    time: string
    subject: string
    className: string
  }
}

// Attendance types
export interface AttendanceSubmission {
  classId: string
  period: number
  date: string
  subject?: string
  attendanceData: {
    studentId: string
    isPresent: boolean
    notes?: string
  }[]
}

export interface AttendanceReport {
  studentId: string
  studentName: string
  rollNo: number
  totalDays: number
  presentDays: number
  absentDays: number
  attendancePercentage: number
  lastAbsentDate?: string
}
