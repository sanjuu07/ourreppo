import { createClient } from "@supabase/supabase-js"
import { SignJWT, jwtVerify, type JWTPayload as JosePayload } from "jose"
import bcrypt from "bcryptjs"
import { cookies } from "next/headers"

// Supabase client setup
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Server-side Supabase client
export const createServerClient = () => {
  return createClient(supabaseUrl, supabaseServiceKey)
}

// JWT utilities
export const JWT_SECRET = process.env.JWT_SECRET || "your-super-secret-jwt-key"
const secret = new TextEncoder().encode(JWT_SECRET)

export interface JWTPayload {
  teacherId: string
  email: string
  name: string
  role: string
}

export async function signJWT(payload: JWTPayload): Promise<string> {
  return new SignJWT(payload as JosePayload).setProtectedHeader({ alg: "HS256" }).setExpirationTime("24h").sign(secret)
}

export async function verifyJWT(token: string): Promise<JWTPayload> {
  const { payload } = await jwtVerify(token, secret)
  return payload as JWTPayload
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12)
}

export async function comparePassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash)
}

// Get current user from request
export async function getCurrentUser() {
  try {
    const cookieStore = cookies()
    const token = cookieStore.get("auth-token")?.value

    if (!token) return null

    const payload = await verifyJWT(token)
    return payload
  } catch {
    return null
  }
}
