"use client"

import { useState, useEffect } from "react"

interface Class {
  id: string
  name: string
  grade: string
  section?: string
  teacher_name?: string
  student_count?: number
  academic_year: string
  is_active: boolean
}

export function useClasses() {
  const [classes, setClasses] = useState<Class[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchClasses()
  }, [])

  const fetchClasses = async () => {
    try {
      setLoading(true)
      setError(null)

      const response = await fetch("/api/classes")
      const data = await response.json()

      if (data.success) {
        setClasses(data.data)
      } else {
        setError(data.error || "Failed to fetch classes")
      }
    } catch (error) {
      console.error("Failed to fetch classes:", error)
      setError("Network error. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  const addClass = async (classData: Omit<Class, "id" | "student_count">) => {
    try {
      const response = await fetch("/api/classes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(classData),
      })

      const data = await response.json()

      if (data.success) {
        await fetchClasses() // Refresh the list
        return { success: true, data: data.data }
      } else {
        return { success: false, error: data.error }
      }
    } catch (error) {
      return { success: false, error: "Network error. Please try again." }
    }
  }

  return {
    classes,
    loading,
    error,
    refetch: fetchClasses,
    addClass,
  }
}
