"use client"

import { useState, useEffect } from "react"

interface DashboardStats {
  presentToday: number
  absentToday: number
  totalStudents: number
  totalClasses: number
  attendanceRate: number
  smssSentToday: number
  nextPeriod?: {
    time: string
    subject: string
    className: string
  }
}

export function useDashboard() {
  const [stats, setStats] = useState<DashboardStats>({
    presentToday: 0,
    absentToday: 0,
    totalStudents: 0,
    totalClasses: 0,
    attendanceRate: 0,
    smssSentToday: 0,
  })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchStats()

    // Refresh stats every 5 minutes
    const interval = setInterval(fetchStats, 5 * 60 * 1000)
    return () => clearInterval(interval)
  }, [])

  const fetchStats = async () => {
    try {
      setError(null)

      const response = await fetch("/api/dashboard/stats")
      const data = await response.json()

      if (data.success) {
        setStats(data.data)
      } else {
        setError(data.error || "Failed to fetch dashboard stats")
      }
    } catch (error) {
      console.error("Failed to fetch dashboard stats:", error)
      setError("Network error. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return {
    stats,
    loading,
    error,
    refetch: fetchStats,
  }
}
