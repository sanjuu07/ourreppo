"use client"

import { useState, useEffect } from "react"

interface Student {
  id: string
  roll_no: number
  name: string
  class_name?: string
  grade?: string
  section?: string
  parent_name?: string
  parent_phone?: string
  parent_email?: string
  address?: string
  date_of_birth?: string
  gender?: string
  blood_group?: string
  is_active: boolean
}

export function useStudents(classId: string | null) {
  const [students, setStudents] = useState<Student[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (classId) {
      fetchStudents(classId)
    } else {
      setStudents([])
    }
  }, [classId])

  const fetchStudents = async (classId: string, search?: string) => {
    try {
      setLoading(true)
      setError(null)

      const params = new URLSearchParams({ classId })
      if (search) params.append("search", search)

      const response = await fetch(`/api/students?${params}`)
      const data = await response.json()

      if (data.success) {
        setStudents(data.data)
      } else {
        setError(data.error || "Failed to fetch students")
      }
    } catch (error) {
      console.error("Failed to fetch students:", error)
      setError("Network error. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  const addStudent = async (studentData: Omit<Student, "id" | "class_name" | "grade" | "section">) => {
    try {
      const response = await fetch("/api/students", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(studentData),
      })

      const data = await response.json()

      if (data.success) {
        if (classId) await fetchStudents(classId) // Refresh the list
        return { success: true, data: data.data }
      } else {
        return { success: false, error: data.error }
      }
    } catch (error) {
      return { success: false, error: "Network error. Please try again." }
    }
  }

  const searchStudents = async (search: string) => {
    if (classId) {
      await fetchStudents(classId, search)
    }
  }

  return {
    students,
    loading,
    error,
    refetch: () => classId && fetchStudents(classId),
    addStudent,
    searchStudents,
  }
}
