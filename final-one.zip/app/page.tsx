"use client"

import type React from "react"
import { useState, useEffect } from "react"
import {
  Calendar,
  Users,
  UserCheck,
  UserX,
  Clock,
  Bell,
  LogOut,
  Home,
  Eye,
  Check,
  X,
  Menu,
  GraduationCap,
  TrendingUp,
  Award,
  Loader2,
  BarChart3,
  Settings,
  FileText,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Sidebar,
  SidebarGroup,
  SidebarGroupContent,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar"
import { useAuth } from "@/hooks/useAuth"
import { useClasses } from "@/hooks/useClasses"
import { useStudents } from "@/hooks/useStudents"
import { useDashboard } from "@/hooks/useDashboard"

interface AttendanceRecord {
  studentId: string
  isPresent: boolean
  notes?: string
}

interface Schedule {
  id: string
  period: number
  subject: string
  start_time: string
  end_time: string
  teacher_name?: string
  room_number?: string
}

interface Absentee {
  student_name: string
  roll_no: number
  date: string
  class_name: string
  period: number
  subject?: string
  sms_sent: boolean
  sms_status?: string
  notes?: string
}

export default function TeacherDashboard() {
  const { teacher, loading: authLoading, login, logout, isAuthenticated } = useAuth()
  const { classes, loading: classesLoading, error: classesError } = useClasses()
  const { stats, loading: statsLoading, refetch: refetchStats } = useDashboard()

  const [currentPage, setCurrentPage] = useState("home")
  const [selectedClassId, setSelectedClassId] = useState<string>("")
  const [selectedPeriod, setSelectedPeriod] = useState("")
  const [showSMSModal, setShowSMSModal] = useState(false)
  const [submissionResult, setSubmissionResult] = useState<any>(null)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [schedule, setSchedule] = useState<Schedule[]>([])
  const [absentees, setAbsentees] = useState<Absentee[]>([])
  const [attendanceData, setAttendanceData] = useState<Record<string, { isPresent: boolean; notes?: string }>>({})
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const { students, loading: studentsLoading, error: studentsError } = useStudents(selectedClassId)

  // Fetch schedule when class is selected
  useEffect(() => {
    if (selectedClassId) {
      fetchSchedule(selectedClassId)
    }
  }, [selectedClassId])

  // Fetch absentees when authenticated
  useEffect(() => {
    if (isAuthenticated) {
      fetchAbsentees()
    }
  }, [isAuthenticated])

  // Initialize attendance data when students change
  useEffect(() => {
    if (students.length > 0) {
      const initialData: Record<string, { isPresent: boolean; notes?: string }> = {}
      students.forEach((student) => {
        initialData[student.id] = { isPresent: true } // Default to present
      })
      setAttendanceData(initialData)
    }
  }, [students])

  const fetchSchedule = async (classId: string) => {
    try {
      const response = await fetch(`/api/schedule?classId=${classId}`)
      const data = await response.json()

      if (data.success) {
        setSchedule(data.data)
      } else {
        console.error("Failed to fetch schedule:", data.error)
      }
    } catch (error) {
      console.error("Failed to fetch schedule:", error)
    }
  }

  const fetchAbsentees = async () => {
    try {
      const response = await fetch("/api/absentees")
      const data = await response.json()

      if (data.success) {
        setAbsentees(data.data)
      } else {
        console.error("Failed to fetch absentees:", data.error)
      }
    } catch (error) {
      console.error("Failed to fetch absentees:", error)
    }
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)

    const formData = new FormData(e.target as HTMLFormElement)
    const email = formData.get("email") as string
    const password = formData.get("password") as string

    const result = await login(email, password)
    if (!result.success) {
      setError(result.error || "Login failed")
    }
  }

  const handleLogout = async () => {
    await logout()
    setCurrentPage("home")
  }

  const toggleAttendance = (studentId: string) => {
    setAttendanceData((prev) => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        isPresent: !prev[studentId]?.isPresent,
      },
    }))
  }

  const updateNotes = (studentId: string, notes: string) => {
    setAttendanceData((prev) => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        notes,
      },
    }))
  }

  const markAllPresent = () => {
    const newData: Record<string, { isPresent: boolean; notes?: string }> = {}
    students.forEach((student) => {
      newData[student.id] = { isPresent: true, notes: attendanceData[student.id]?.notes }
    })
    setAttendanceData(newData)
  }

  const markAllAbsent = () => {
    const newData: Record<string, { isPresent: boolean; notes?: string }> = {}
    students.forEach((student) => {
      newData[student.id] = { isPresent: false, notes: attendanceData[student.id]?.notes }
    })
    setAttendanceData(newData)
  }

  const handleAttendanceSubmit = async () => {
    if (!selectedClassId || !selectedPeriod) {
      setError("Please select class and period")
      return
    }

    setSubmitting(true)
    setError(null)

    try {
      const attendanceRecords: AttendanceRecord[] = Object.entries(attendanceData).map(([studentId, data]) => ({
        studentId,
        isPresent: data.isPresent,
        notes: data.notes,
      }))

      const response = await fetch("/api/attendance", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          classId: selectedClassId,
          period: Number.parseInt(selectedPeriod),
          attendanceData: attendanceRecords,
          date: new Date().toISOString().split("T")[0],
          subject: schedule.find((s) => s.period === Number.parseInt(selectedPeriod))?.subject,
        }),
      })

      const data = await response.json()

      if (data.success) {
        setSubmissionResult(data.data)
        setShowSMSModal(true)
        refetchStats() // Refresh dashboard stats
        fetchAbsentees() // Refresh absentees
      } else {
        setError(data.error || "Failed to submit attendance")
      }
    } catch (error) {
      console.error("Failed to submit attendance:", error)
      setError("Network error. Please try again.")
    } finally {
      setSubmitting(false)
    }
  }

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-cyan-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-blue-600" />
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    )
  }

  // Login Page
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-cyan-50 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <Card className="shadow-2xl border-0 bg-white/80 backdrop-blur-sm">
            <CardHeader className="text-center space-y-6 pb-8">
              <div className="mx-auto w-20 h-20 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-2xl flex items-center justify-center shadow-lg">
                <GraduationCap className="w-10 h-10 text-white" />
              </div>
              <div className="space-y-2">
                <CardTitle className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                  Greenwood School
                </CardTitle>
                <CardDescription className="text-gray-600 text-lg">Teacher Portal</CardDescription>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {error && (
                <Alert className="border-red-200 bg-red-50">
                  <AlertDescription className="text-red-700">{error}</AlertDescription>
                </Alert>
              )}
              <form onSubmit={handleLogin} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-sm font-medium text-gray-700">
                    Email Address
                  </Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="teacher@greenwood.edu"
                    required
                    className="h-12 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password" className="text-sm font-medium text-gray-700">
                    Password
                  </Label>
                  <Input
                    id="password"
                    name="password"
                    type="password"
                    placeholder="Enter your password"
                    required
                    className="h-12 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                <Button
                  type="submit"
                  className="w-full h-12 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-medium rounded-lg shadow-lg hover:shadow-xl transition-all duration-200"
                >
                  Sign In to Dashboard
                </Button>
              </form>
              <div className="text-center text-sm text-gray-600 bg-blue-50 p-4 rounded-lg">
                <p className="font-medium mb-2">Demo Credentials:</p>
                <p>Email: teacher@greenwood.edu</p>
                <p>Password: teacher123</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  // Sidebar Navigation
  const sidebarItems = [
    { icon: Home, label: "Dashboard", page: "home" },
    { icon: UserCheck, label: "Take Attendance", page: "attendance" },
    { icon: Eye, label: "View Absentees", page: "absentees" },
    { icon: Calendar, label: "Schedule", page: "schedule" },
    { icon: BarChart3, label: "Reports", page: "reports" },
    { icon: FileText, label: "SMS Logs", page: "sms-logs" },
  ]

  if (teacher?.role === "admin") {
    sidebarItems.push({ icon: Settings, label: "Admin Panel", page: "admin" })
  }

  const SidebarContent = () => (
    <>
      <SidebarHeader className="border-b border-gray-100 p-6">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-xl flex items-center justify-center shadow-lg">
            <GraduationCap className="w-7 h-7 text-white" />
          </div>
          <div>
            <h2 className="font-bold text-gray-900 text-lg">Greenwood</h2>
            <p className="text-sm text-gray-500">Teacher Portal</p>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup className="px-4 py-6">
          <SidebarGroupContent>
            <SidebarMenu className="space-y-2">
              {sidebarItems.map((item) => (
                <SidebarMenuItem key={item.page}>
                  <SidebarMenuButton
                    onClick={() => {
                      setCurrentPage(item.page)
                      setIsMobileMenuOpen(false)
                    }}
                    isActive={currentPage === item.page}
                    className="w-full justify-start h-12 rounded-xl font-medium transition-all duration-200 hover:bg-blue-50 data-[active=true]:bg-gradient-to-r data-[active=true]:from-blue-600 data-[active=true]:to-indigo-600 data-[active=true]:text-white data-[active=true]:shadow-lg"
                  >
                    <item.icon className="w-5 h-5" />
                    <span>{item.label}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
              <SidebarMenuItem className="mt-8">
                <SidebarMenuButton
                  onClick={handleLogout}
                  className="w-full justify-start h-12 rounded-xl font-medium text-red-600 hover:text-red-700 hover:bg-red-50 transition-all duration-200"
                >
                  <LogOut className="w-5 h-5" />
                  <span>Logout</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </>
  )

  const selectedClass = classes.find((c) => c.id === selectedClassId)

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50/30">
      {/* Mobile Navigation */}
      <div className="lg:hidden">
        <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
          <div className="flex items-center justify-between p-4 bg-white border-b border-gray-200">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-lg flex items-center justify-center">
                <GraduationCap className="w-6 h-6 text-white" />
              </div>
              <h1 className="font-bold text-gray-900">Greenwood</h1>
            </div>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
          </div>
          <SheetContent side="left" className="p-0 w-80">
            <Sidebar className="border-0">
              <SidebarContent />
            </Sidebar>
          </SheetContent>
        </Sheet>
      </div>

      {/* Desktop Layout */}
      <div className="hidden lg:flex">
        <SidebarProvider>
          <Sidebar className="border-r border-gray-200 bg-white">
            <SidebarContent />
          </Sidebar>

          <SidebarInset className="flex-1">
            {/* Top Bar */}
            <header className="bg-white/80 backdrop-blur-sm border-b border-gray-200 px-4 lg:px-8 py-4 sticky top-0 z-10">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <SidebarTrigger className="lg:hidden" />
                  <div>
                    <h1 className="text-xl lg:text-2xl font-bold text-gray-900">
                      {currentPage === "home" && "Dashboard Overview"}
                      {currentPage === "attendance" && "Take Attendance"}
                      {currentPage === "absentees" && "View Absentees"}
                      {currentPage === "schedule" && "Class Schedule"}
                      {currentPage === "reports" && "Attendance Reports"}
                      {currentPage === "sms-logs" && "SMS Logs"}
                      {currentPage === "admin" && "Admin Panel"}
                    </h1>
                    <p className="text-sm text-gray-500 hidden sm:block">
                      {new Date().toLocaleDateString("en-US", {
                        weekday: "long",
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                      })}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="hidden md:flex items-center space-x-3 bg-gradient-to-r from-blue-50 to-indigo-50 px-4 py-2 rounded-full">
                    <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-full flex items-center justify-center">
                      <span className="text-white text-sm font-medium">
                        {teacher?.name
                          ?.split(" ")
                          .map((n) => n[0])
                          .join("") || "T"}
                      </span>
                    </div>
                    <div className="text-left">
                      <span className="text-sm font-medium text-gray-700 block">{teacher?.name}</span>
                      <span className="text-xs text-gray-500 capitalize">{teacher?.role}</span>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" className="relative">
                    <Bell className="w-5 h-5 text-gray-600" />
                    <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></span>
                  </Button>
                </div>
              </div>
            </header>

            {/* Main Content */}
            <main className="p-4 lg:p-8">
              {/* Global Error Display */}
              {error && (
                <Alert className="mb-6 border-red-200 bg-red-50">
                  <AlertDescription className="text-red-700">{error}</AlertDescription>
                </Alert>
              )}

              {/* Home Dashboard */}
              {currentPage === "home" && (
                <div className="space-y-6 lg:space-y-8">
                  {/* Welcome Section */}
                  <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 rounded-2xl p-6 lg:p-8 text-white relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16"></div>
                    <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full translate-y-12 -translate-x-12"></div>
                    <div className="relative z-10">
                      <h2 className="text-2xl lg:text-3xl font-bold mb-2">
                        Welcome back, {teacher?.name?.split(" ")[0]}! 👋
                      </h2>
                      <p className="text-blue-100 text-lg">
                        Ready to inspire young minds today? Let's make learning magical!
                      </p>
                      <div className="mt-4 flex items-center space-x-4 text-blue-100">
                        <span className="text-sm">Role: {teacher?.role}</span>
                        {teacher?.department && <span className="text-sm">Department: {teacher?.department}</span>}
                      </div>
                    </div>
                  </div>

                  {/* Stats Cards */}
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
                    <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200 hover:shadow-lg transition-all duration-200">
                      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium text-green-800">Present Today</CardTitle>
                        <div className="w-8 h-8 bg-green-500 rounded-lg flex items-center justify-center">
                          <UserCheck className="h-4 w-4 text-white" />
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl lg:text-3xl font-bold text-green-700">
                          {statsLoading ? <Loader2 className="w-6 h-6 animate-spin" /> : stats.presentToday}
                        </div>
                        <p className="text-xs text-green-600 flex items-center mt-1">
                          <TrendingUp className="w-3 h-3 mr-1" />
                          {stats.attendanceRate}% attendance rate
                        </p>
                      </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-red-50 to-rose-50 border-red-200 hover:shadow-lg transition-all duration-200">
                      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium text-red-800">Absent Today</CardTitle>
                        <div className="w-8 h-8 bg-red-500 rounded-lg flex items-center justify-center">
                          <UserX className="h-4 w-4 text-white" />
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl lg:text-3xl font-bold text-red-700">
                          {statsLoading ? <Loader2 className="w-6 h-6 animate-spin" /> : stats.absentToday}
                        </div>
                        <p className="text-xs text-red-600 flex items-center mt-1">
                          <TrendingUp className="w-3 h-3 mr-1 rotate-180" />
                          {stats.smssSentToday} SMS sent
                        </p>
                      </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 border-blue-200 hover:shadow-lg transition-all duration-200">
                      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium text-blue-800">Total Students</CardTitle>
                        <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center">
                          <Users className="h-4 w-4 text-white" />
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl lg:text-3xl font-bold text-blue-700">
                          {statsLoading ? <Loader2 className="w-6 h-6 animate-spin" /> : stats.totalStudents}
                        </div>
                        <p className="text-xs text-blue-600">Across {stats.totalClasses} classes</p>
                      </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-orange-50 to-amber-50 border-orange-200 hover:shadow-lg transition-all duration-200">
                      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium text-orange-800">Next Period</CardTitle>
                        <div className="w-8 h-8 bg-orange-500 rounded-lg flex items-center justify-center">
                          <Clock className="h-4 w-4 text-white" />
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl lg:text-3xl font-bold text-orange-700">
                          {stats.nextPeriod?.time || "--:--"}
                        </div>
                        <p className="text-xs text-orange-600">{stats.nextPeriod?.subject || "No upcoming periods"}</p>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Quick Actions & Recent Activity */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-8">
                    <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
                      <CardHeader className="pb-4">
                        <CardTitle className="flex items-center space-x-2">
                          <Award className="w-5 h-5 text-blue-600" />
                          <span>Quick Class Selection</span>
                        </CardTitle>
                        <CardDescription>Jump to any class instantly</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {classesError && (
                          <Alert className="border-red-200 bg-red-50">
                            <AlertDescription className="text-red-700">{classesError}</AlertDescription>
                          </Alert>
                        )}
                        <Select value={selectedClassId} onValueChange={setSelectedClassId}>
                          <SelectTrigger className="h-12 border-gray-200 focus:border-blue-500">
                            <SelectValue placeholder="Choose your class" />
                          </SelectTrigger>
                          <SelectContent>
                            {classesLoading ? (
                              <SelectItem value="loading" disabled>
                                <Loader2 className="w-4 h-4 animate-spin mr-2" />
                                Loading classes...
                              </SelectItem>
                            ) : (
                              classes.map((cls) => (
                                <SelectItem key={cls.id} value={cls.id} className="py-3">
                                  <div className="flex items-center space-x-2">
                                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                                    <span>{cls.name}</span>
                                    <Badge variant="outline" className="ml-2">
                                      {cls.student_count || 0} students
                                    </Badge>
                                  </div>
                                </SelectItem>
                              ))
                            )}
                          </SelectContent>
                        </Select>
                        {selectedClass && (
                          <div className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg">
                            <p className="text-sm font-medium text-blue-800">Selected: {selectedClass.name}</p>
                            <p className="text-xs text-blue-600 mt-1">
                              {selectedClass.student_count || 0} students • Grade {selectedClass.grade}
                              {selectedClass.section && ` Section ${selectedClass.section}`}
                            </p>
                          </div>
                        )}
                      </CardContent>
                    </Card>

                    <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
                      <CardHeader className="pb-4">
                        <CardTitle className="flex items-center space-x-2">
                          <Clock className="w-5 h-5 text-indigo-600" />
                          <span>Today's Schedule</span>
                        </CardTitle>
                        <CardDescription>Your upcoming periods</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          {stats.nextPeriod ? (
                            <>
                              <div className="flex justify-between items-center p-3 bg-gradient-to-r from-blue-50 to-blue-100 rounded-lg border-l-4 border-blue-500">
                                <div>
                                  <span className="font-semibold text-blue-900">{stats.nextPeriod.subject}</span>
                                  <p className="text-xs text-blue-700">Next Period</p>
                                </div>
                                <span className="text-sm font-medium text-blue-800">{stats.nextPeriod.time}</span>
                              </div>
                              <div className="text-center py-4">
                                <Button
                                  onClick={() => setCurrentPage("attendance")}
                                  className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                                >
                                  <UserCheck className="w-4 h-4 mr-2" />
                                  Take Attendance
                                </Button>
                              </div>
                            </>
                          ) : (
                            <div className="text-center py-8 text-gray-500">
                              <Clock className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                              <p>No upcoming periods scheduled</p>
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              )}

              {/* Take Attendance Page */}
              {currentPage === "attendance" && (
                <div className="space-y-6">
                  <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2 text-2xl">
                        <UserCheck className="w-7 h-7 text-green-600" />
                        <span>Take Attendance</span>
                      </CardTitle>
                      <CardDescription className="text-lg">
                        Simple and quick attendance marking for your class
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      {/* Step 1: Class and Period Selection */}
                      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-xl mb-8">
                        <h3 className="text-xl font-semibold text-blue-900 mb-4">Step 1: Select Your Class & Period</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div className="space-y-3">
                            <Label htmlFor="class-select" className="text-lg font-medium text-gray-700">
                              Choose Class
                            </Label>
                            <Select value={selectedClassId} onValueChange={setSelectedClassId}>
                              <SelectTrigger className="h-16 text-lg border-2 border-gray-200 focus:border-blue-500">
                                <SelectValue placeholder="Select your class" />
                              </SelectTrigger>
                              <SelectContent>
                                {classes.map((cls) => (
                                  <SelectItem key={cls.id} value={cls.id} className="py-4 text-lg">
                                    <div className="flex items-center space-x-3">
                                      <div className="w-4 h-4 bg-blue-500 rounded-full"></div>
                                      <span className="font-medium">{cls.name}</span>
                                    </div>
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-3">
                            <Label htmlFor="period-select" className="text-lg font-medium text-gray-700">
                              Choose Period
                            </Label>
                            <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                              <SelectTrigger className="h-16 text-lg border-2 border-gray-200 focus:border-blue-500">
                                <SelectValue placeholder="Select your period" />
                              </SelectTrigger>
                              <SelectContent>
                                {schedule.map((sched) => (
                                  <SelectItem key={sched.id} value={sched.period.toString()} className="py-4 text-lg">
                                    <div className="flex items-center space-x-3">
                                      <div className="w-4 h-4 bg-indigo-500 rounded-full"></div>
                                      <span className="font-medium">Period {sched.period}</span>
                                    </div>
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                      </div>

                      {/* Step 2: Mark Attendance */}
                      <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-6 rounded-xl mb-8">
                        <h3 className="text-xl font-semibold text-emerald-900 mb-4">Step 2: Mark Attendance</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div className="space-y-3">
                            <Button
                              onClick={markAllPresent}
                              className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                            >
                              <Check className="w-4 h-4 mr-2" />
                              Mark All Present
                            </Button>
                            <Button
                              onClick={markAllAbsent}
                              className="bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700"
                            >
                              <X className="w-4 h-4 mr-2" />
                              Mark All Absent
                            </Button>
                          </div>
                          <div className="space-y-3">
                            {students.map((student) => (
                              <div key={student.id} className="flex items-center space-x-4">
                                <Button
                                  onClick={() => toggleAttendance(student.id)}
                                  className={`w-12 h-12 rounded-full ${
                                    attendanceData[student.id]?.isPresent ? "bg-green-600" : "bg-red-600"
                                  }`}
                                >
                                  {attendanceData[student.id]?.isPresent ? (
                                    <UserCheck className="w-6 h-6 text-white" />
                                  ) : (
                                    <UserX className="w-6 h-6 text-white" />
                                  )}
                                </Button>
                                <div className="flex-1">
                                  <p className="text-lg font-medium text-gray-900">{student.name}</p>
                                  <p className="text-sm text-gray-500">Roll No: {student.roll_no}</p>
                                </div>
                                <Textarea
                                  value={attendanceData[student.id]?.notes || ""}
                                  onChange={(e) => updateNotes(student.id, e.target.value)}
                                  placeholder="Add notes..."
                                  className="h-12 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                                />
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>

                      {/* Step 3: Submit Attendance */}
                      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-xl">
                        <Button
                          onClick={handleAttendanceSubmit}
                          className="w-full h-12 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-medium rounded-lg shadow-lg hover:shadow-xl transition-all duration-200"
                          disabled={submitting}
                        >
                          {submitting ? (
                            <>
                              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                              Submitting...
                            </>
                          ) : (
                            <>
                              <UserCheck className="w-4 h-4 mr-2" />
                              Submit Attendance
                            </>
                          )}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}

              {/* View Absentees Page */}
              {currentPage === "absentees" && (
                <div className="space-y-6">
                  <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2 text-2xl">
                        <Eye className="w-7 h-7 text-blue-600" />
                        <span>View Absentees</span>
                      </CardTitle>
                      <CardDescription className="text-lg">List of students who are absent today</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Student Name</TableHead>
                            <TableHead>Roll No</TableHead>
                            <TableHead>Class</TableHead>
                            <TableHead>Period</TableHead>
                            <TableHead>Subject</TableHead>
                            <TableHead>SMS Sent</TableHead>
                            <TableHead>Notes</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {absentees.map((absentee) => (
                            <TableRow key={absentee.student_name}>
                              <TableCell>{absentee.student_name}</TableCell>
                              <TableCell>{absentee.roll_no}</TableCell>
                              <TableCell>{absentee.class_name}</TableCell>
                              <TableCell>{absentee.period}</TableCell>
                              <TableCell>{absentee.subject}</TableCell>
                              <TableCell>
                                {absentee.sms_sent ? (
                                  <Badge variant="success">Sent</Badge>
                                ) : (
                                  <Badge variant="destructive">Not Sent</Badge>
                                )}
                              </TableCell>
                              <TableCell>{absentee.notes}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </CardContent>
                  </Card>
                </div>
              )}

              {/* Schedule Page */}
              {currentPage === "schedule" && (
                <div className="space-y-6">
                  <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2 text-2xl">
                        <Calendar className="w-7 h-7 text-blue-600" />
                        <span>Class Schedule</span>
                      </CardTitle>
                      <CardDescription className="text-lg">Your class schedule for the day</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Period</TableHead>
                            <TableHead>Subject</TableHead>
                            <TableHead>Start Time</TableHead>
                            <TableHead>End Time</TableHead>
                            <TableHead>Teacher</TableHead>
                            <TableHead>Room</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {schedule.map((sched) => (
                            <TableRow key={sched.id}>
                              <TableCell>{sched.period}</TableCell>
                              <TableCell>{sched.subject}</TableCell>
                              <TableCell>{sched.start_time}</TableCell>
                              <TableCell>{sched.end_time}</TableCell>
                              <TableCell>{sched.teacher_name}</TableCell>
                              <TableCell>{sched.room_number}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </CardContent>
                  </Card>
                </div>
              )}

              {/* Reports Page */}
              {currentPage === "reports" && (
                <div className="space-y-6">
                  <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2 text-2xl">
                        <BarChart3 className="w-7 h-7 text-blue-600" />
                        <span>Attendance Reports</span>
                      </CardTitle>
                      <CardDescription className="text-lg">View attendance reports for your classes</CardDescription>
                    </CardHeader>
                    <CardContent>
                      {/* Placeholder for reports */}
                      <p className="text-center text-gray-500">Reports will be displayed here</p>
                    </CardContent>
                  </Card>
                </div>
              )}

              {/* SMS Logs Page */}
              {currentPage === "sms-logs" && (
                <div className="space-y-6">
                  <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2 text-2xl">
                        <FileText className="w-7 h-7 text-blue-600" />
                        <span>SMS Logs</span>
                      </CardTitle>
                      <CardDescription className="text-lg">Logs of SMS sent to absentees</CardDescription>
                    </CardHeader>
                    <CardContent>
                      {/* Placeholder for SMS logs */}
                      <p className="text-center text-gray-500">SMS logs will be displayed here</p>
                    </CardContent>
                  </Card>
                </div>
              )}

              {/* Admin Panel Page */}
              {currentPage === "admin" && (
                <div className="space-y-6">
                  <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2 text-2xl">
                        <Settings className="w-7 h-7 text-blue-600" />
                        <span>Admin Panel</span>
                      </CardTitle>
                      <CardDescription className="text-lg">
                        Administrative tools for managing the portal
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      {/* Placeholder for admin panel */}
                      <p className="text-center text-gray-500">Admin panel tools will be displayed here</p>
                    </CardContent>
                  </Card>
                </div>
              )}
            </main>
          </SidebarInset>
        </SidebarProvider>
      </div>
    </div>
  )
}
