// Since there is no existing code, we will create a new file.
// This example demonstrates a simple API route.
// Replace this with your actual API route logic.

import { NextResponse } from "next/server"
import { getCurrentUser } from "@/lib/session"

export async function GET(request: Request) {
  const user = await getCurrentUser()

  if (!user) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
  }

  return NextResponse.json({ message: "Hello from the API!", user: user })
}

export async function POST(request: Request) {
  const user = await getCurrentUser()

  if (!user) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
  }

  try {
    const body = await request.json()
    // Process the request body here
    return NextResponse.json({ message: "Data received", data: body })
  } catch (error) {
    return NextResponse.json({ message: "Invalid request body" }, { status: 400 })
  }
}
