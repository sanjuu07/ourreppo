import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"
import { validateRequest, dateRangeSchema, paginationSchema } from "@/lib/validation"

export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const classId = searchParams.get("classId")

    const dateValidation = validateRequest(dateRangeSchema, Object.fromEntries(searchParams))
    const paginationValidation = validateRequest(paginationSchema, Object.fromEntries(searchParams))

    const { startDate, endDate } = dateValidation.data || {}
    const { page, limit } = paginationValidation.data || { page: 1, limit: 50 }

    const offset = (page - 1) * limit

    let baseQuery = sql`
      SELECT 
        s.name as student_name,
        s.roll_no,
        ar.date,
        c.name as class_name,
        ar.period,
        ar.subject,
        ar.sms_sent,
        ar.sms_sent_at,
        ar.notes,
        ar.marked_at,
        sl.status as sms_status,
        sl.error_message as sms_error
      FROM attendance_records ar
      JOIN students s ON ar.student_id = s.id
      JOIN classes c ON ar.class_id = c.id
      LEFT JOIN sms_logs sl ON s.id = sl.student_id 
        AND DATE(sl.created_at) = ar.date
      WHERE ar.is_present = false
    `

    const conditions = []
    const params = []

    // Filter by teacher if not admin
    if (user.role !== "admin") {
      conditions.push(`c.teacher_id = $${params.length + 1}`)
      params.push(user.teacherId)
    }

    // Filter by class
    if (classId && classId !== "all") {
      conditions.push(`ar.class_id = $${params.length + 1}`)
      params.push(classId)
    }

    // Filter by date range
    if (startDate) {
      conditions.push(`ar.date >= $${params.length + 1}`)
      params.push(startDate)
    }

    if (endDate) {
      conditions.push(`ar.date <= $${params.length + 1}`)
      params.push(endDate)
    }

    if (conditions.length > 0) {
      baseQuery = sql`${baseQuery} AND ${sql.raw(conditions.join(" AND "))}`
    }

    const absentees = await sql`
      ${baseQuery}
      ORDER BY ar.date DESC, c.name, s.roll_no
      LIMIT ${limit} OFFSET ${offset}
    `

    // Get total count for pagination
    let countQuery = sql`
      SELECT COUNT(*) as total
      FROM attendance_records ar
      JOIN students s ON ar.student_id = s.id
      JOIN classes c ON ar.class_id = c.id
      WHERE ar.is_present = false
    `

    if (conditions.length > 0) {
      countQuery = sql`${countQuery} AND ${sql.raw(conditions.join(" AND "))}`
    }

    const [{ total }] = await countQuery
    const totalPages = Math.ceil(Number(total) / limit)

    return NextResponse.json({
      success: true,
      data: absentees,
      pagination: {
        page,
        limit,
        total: Number(total),
        totalPages,
      },
    })
  } catch (error) {
    console.error("Absentees fetch error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
