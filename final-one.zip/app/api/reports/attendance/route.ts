import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"
import { validateRequest, dateRangeSchema } from "@/lib/validation"

export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const classId = searchParams.get("classId")
    const reportType = searchParams.get("type") || "summary" // summary, detailed, student

    const dateValidation = validateRequest(dateRangeSchema, Object.fromEntries(searchParams))
    const { startDate, endDate } = dateValidation.data || {}

    if (!classId) {
      return NextResponse.json({ error: "Class ID is required" }, { status: 400 })
    }

    // Verify user has access to this class
    if (user.role !== "admin") {
      const classAccess = await sql`
        SELECT id FROM classes 
        WHERE id = ${classId} AND teacher_id = ${user.teacherId} AND is_active = true
      `

      if (classAccess.length === 0) {
        return NextResponse.json({ error: "Access denied to this class" }, { status: 403 })
      }
    }

    let reportData

    if (reportType === "summary") {
      // Summary report: Overall class attendance statistics
      reportData = await sql`
        SELECT 
          c.name as class_name,
          c.grade,
          c.section,
          COUNT(DISTINCT s.id) as total_students,
          COUNT(ar.id) as total_attendance_records,
          SUM(CASE WHEN ar.is_present = true THEN 1 ELSE 0 END) as total_present,
          SUM(CASE WHEN ar.is_present = false THEN 1 ELSE 0 END) as total_absent,
          ROUND(
            (SUM(CASE WHEN ar.is_present = true THEN 1 ELSE 0 END)::float / 
             NULLIF(COUNT(ar.id), 0)) * 100, 2
          ) as attendance_percentage,
          COUNT(DISTINCT ar.date) as total_days_recorded
        FROM classes c
        JOIN students s ON c.id = s.class_id AND s.is_active = true
        LEFT JOIN attendance_records ar ON s.id = ar.student_id
          ${startDate ? sql`AND ar.date >= ${startDate}` : sql``}
          ${endDate ? sql`AND ar.date <= ${endDate}` : sql``}
        WHERE c.id = ${classId}
        GROUP BY c.id, c.name, c.grade, c.section
      `
    } else if (reportType === "detailed") {
      // Detailed report: Day-wise attendance
      reportData = await sql`
        SELECT 
          ar.date,
          ar.period,
          ar.subject,
          COUNT(*) as total_students,
          SUM(CASE WHEN ar.is_present = true THEN 1 ELSE 0 END) as present_count,
          SUM(CASE WHEN ar.is_present = false THEN 1 ELSE 0 END) as absent_count,
          ROUND(
            (SUM(CASE WHEN ar.is_present = true THEN 1 ELSE 0 END)::float / 
             COUNT(*)) * 100, 2
          ) as attendance_percentage
        FROM attendance_records ar
        JOIN students s ON ar.student_id = s.id
        WHERE ar.class_id = ${classId}
          ${startDate ? sql`AND ar.date >= ${startDate}` : sql``}
          ${endDate ? sql`AND ar.date <= ${endDate}` : sql``}
        GROUP BY ar.date, ar.period, ar.subject
        ORDER BY ar.date DESC, ar.period
      `
    } else if (reportType === "student") {
      // Student-wise report: Individual attendance records
      reportData = await sql`
        SELECT 
          s.roll_no,
          s.name as student_name,
          s.parent_name,
          s.parent_phone,
          COUNT(ar.id) as total_days,
          SUM(CASE WHEN ar.is_present = true THEN 1 ELSE 0 END) as present_days,
          SUM(CASE WHEN ar.is_present = false THEN 1 ELSE 0 END) as absent_days,
          ROUND(
            (SUM(CASE WHEN ar.is_present = true THEN 1 ELSE 0 END)::float / 
             NULLIF(COUNT(ar.id), 0)) * 100, 2
          ) as attendance_percentage,
          MAX(CASE WHEN ar.is_present = false THEN ar.date END) as last_absent_date
        FROM students s
        LEFT JOIN attendance_records ar ON s.id = ar.student_id
          ${startDate ? sql`AND ar.date >= ${startDate}` : sql``}
          ${endDate ? sql`AND ar.date <= ${endDate}` : sql``}
        WHERE s.class_id = ${classId} AND s.is_active = true
        GROUP BY s.id, s.roll_no, s.name, s.parent_name, s.parent_phone
        ORDER BY s.roll_no
      `
    }

    return NextResponse.json({
      success: true,
      data: reportData,
      reportType,
      filters: {
        classId,
        startDate,
        endDate,
      },
    })
  } catch (error) {
    console.error("Attendance report error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
