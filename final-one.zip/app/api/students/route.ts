import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"
import { validateRequest, studentSchema } from "@/lib/validation"
import { createAuditLog } from "@/lib/audit"

export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const classId = searchParams.get("classId")
    const search = searchParams.get("search")

    if (!classId) {
      return NextResponse.json({ error: "Class ID is required" }, { status: 400 })
    }

    // Verify user has access to this class
    if (user.role !== "admin") {
      const classAccess = await sql`
        SELECT id FROM classes 
        WHERE id = ${classId} AND teacher_id = ${user.teacherId} AND is_active = true
      `

      if (classAccess.length === 0) {
        return NextResponse.json({ error: "Access denied to this class" }, { status: 403 })
      }
    }

    let studentsQuery = sql`
      SELECT s.*, c.name as class_name, c.grade, c.section
      FROM students s
      JOIN classes c ON s.class_id = c.id
      WHERE s.class_id = ${classId} AND s.is_active = true
    `

    if (search) {
      studentsQuery = sql`
        SELECT s.*, c.name as class_name, c.grade, c.section
        FROM students s
        JOIN classes c ON s.class_id = c.id
        WHERE s.class_id = ${classId} AND s.is_active = true
        AND (s.name ILIKE ${"%" + search + "%"} OR s.roll_no::text ILIKE ${"%" + search + "%"})
      `
    }

    studentsQuery = sql`${studentsQuery} ORDER BY s.roll_no`

    const students = await studentsQuery

    return NextResponse.json({
      success: true,
      data: students,
    })
  } catch (error) {
    console.error("Students fetch error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const validation = validateRequest(studentSchema, body)

    if (!validation.success) {
      return NextResponse.json({ error: "Validation failed", details: validation.errors }, { status: 400 })
    }

    const { rollNo, name, classId, parentName, parentPhone, parentEmail, address, dateOfBirth, gender, bloodGroup } =
      validation.data

    // Verify user has access to this class
    if (user.role !== "admin") {
      const classAccess = await sql`
        SELECT id FROM classes 
        WHERE id = ${classId} AND teacher_id = ${user.teacherId} AND is_active = true
      `

      if (classAccess.length === 0) {
        return NextResponse.json({ error: "Access denied to this class" }, { status: 403 })
      }
    }

    // Check if roll number already exists in the class
    const existingStudent = await sql`
      SELECT id FROM students 
      WHERE class_id = ${classId} AND roll_no = ${rollNo} AND is_active = true
    `

    if (existingStudent.length > 0) {
      return NextResponse.json({ error: "Roll number already exists in this class" }, { status: 400 })
    }

    const [newStudent] = await sql`
      INSERT INTO students (
        roll_no, name, class_id, parent_name, parent_phone, parent_email,
        address, date_of_birth, gender, blood_group
      )
      VALUES (
        ${rollNo}, ${name}, ${classId}, ${parentName}, ${parentPhone}, ${parentEmail},
        ${address}, ${dateOfBirth}, ${gender}, ${bloodGroup}
      )
      RETURNING *
    `

    await createAuditLog({
      action: "create_student",
      resourceType: "student",
      resourceId: newStudent.id,
      newValues: newStudent,
    })

    return NextResponse.json({
      success: true,
      data: newStudent,
      message: "Student added successfully",
    })
  } catch (error) {
    console.error("Student creation error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
