import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const today = new Date().toISOString().split("T")[0]

    // Get today's attendance stats
    let attendanceStatsQuery
    let classCountQuery
    let totalStudentsQuery
    let smsStatsQuery

    if (user.role === "admin") {
      // Admin sees all stats
      attendanceStatsQuery = sql`
        SELECT 
          COUNT(*) as total_records,
          SUM(CASE WHEN is_present = true THEN 1 ELSE 0 END) as present_count,
          SUM(CASE WHEN is_present = false THEN 1 ELSE 0 END) as absent_count
        FROM attendance_records ar
        WHERE ar.date = ${today}
      `

      classCountQuery = sql`
        SELECT COUNT(*) as total_classes
        FROM classes
        WHERE is_active = true
      `

      totalStudentsQuery = sql`
        SELECT COUNT(*) as total_students
        FROM students
        WHERE is_active = true
      `

      smsStatsQuery = sql`
        SELECT COUNT(*) as sms_sent_today
        FROM sms_logs
        WHERE DATE(created_at) = ${today} AND status = 'sent'
      `
    } else {
      // Teacher sees only their stats
      attendanceStatsQuery = sql`
        SELECT 
          COUNT(*) as total_records,
          SUM(CASE WHEN is_present = true THEN 1 ELSE 0 END) as present_count,
          SUM(CASE WHEN is_present = false THEN 1 ELSE 0 END) as absent_count
        FROM attendance_records ar
        JOIN classes c ON ar.class_id = c.id
        WHERE c.teacher_id = ${user.teacherId}
          AND ar.date = ${today}
      `

      classCountQuery = sql`
        SELECT COUNT(*) as total_classes
        FROM classes
        WHERE teacher_id = ${user.teacherId} AND is_active = true
      `

      totalStudentsQuery = sql`
        SELECT COUNT(*) as total_students
        FROM students s
        JOIN classes c ON s.class_id = c.id
        WHERE c.teacher_id = ${user.teacherId} AND s.is_active = true
      `

      smsStatsQuery = sql`
        SELECT COUNT(*) as sms_sent_today
        FROM sms_logs sl
        WHERE sl.teacher_id = ${user.teacherId}
          AND DATE(sl.created_at) = ${today} 
          AND sl.status = 'sent'
      `
    }

    const [attendanceStats, classCount, totalStudents, smsStats] = await Promise.all([
      attendanceStatsQuery,
      classCountQuery,
      totalStudentsQuery,
      smsStatsQuery,
    ])

    // Get next period info
    const nextPeriod = await sql`
      SELECT 
        s.subject,
        s.start_time,
        c.name as class_name
      FROM schedules s
      JOIN classes c ON s.class_id = c.id
      WHERE s.teacher_id = ${user.teacherId}
        AND s.day_of_week = EXTRACT(DOW FROM NOW())
        AND s.start_time > CURRENT_TIME
        AND s.is_active = true
      ORDER BY s.start_time
      LIMIT 1
    `

    const presentToday = Number(attendanceStats[0]?.present_count || 0)
    const absentToday = Number(attendanceStats[0]?.absent_count || 0)
    const totalStudentsCount = Number(totalStudents[0]?.total_students || 0)
    const attendanceRate = totalStudentsCount > 0 ? Math.round((presentToday / totalStudentsCount) * 100) : 0

    return NextResponse.json({
      success: true,
      data: {
        presentToday,
        absentToday,
        totalStudents: totalStudentsCount,
        totalClasses: Number(classCount[0]?.total_classes || 0),
        attendanceRate,
        smssSentToday: Number(smsStats[0]?.sms_sent_today || 0),
        nextPeriod: nextPeriod[0]
          ? {
              time: nextPeriod[0].start_time,
              subject: nextPeriod[0].subject,
              className: nextPeriod[0].class_name,
            }
          : undefined,
      },
    })
  } catch (error) {
    console.error("Dashboard stats error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
