-- Insert demo teachers with hashed passwords
INSERT INTO teachers (email, name, phone, password_hash, role, department) VALUES 
('teacher@greenwood.edu', 'Mrs. Sarah Johnson', '+1234567890', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/VcSAg/9qm', 'teacher', 'Primary Education'),
('admin@greenwood.edu', 'Mr. John Smith', '+1234567891', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/VcSAg/9qm', 'admin', 'Administration'),
('demo@greenwood.edu', 'Ms. Emily Davis', '+1234567892', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/VcSAg/9qm', 'teacher', 'Elementary')
ON CONFLICT (email) DO NOTHING;

-- Get teacher IDs for foreign key references
DO $$
DECLARE
    sarah_id UUID;
    john_id UUID;
    emily_id UUID;
    nursery_id UUID;
    fifth_id UUID;
    first_id UUID;
    third_id UUID;
BEGIN
    SELECT id INTO sarah_id FROM teachers WHERE email = 'teacher@greenwood.edu';
    SELECT id INTO john_id FROM teachers WHERE email = 'admin@greenwood.edu';
    SELECT id INTO emily_id FROM teachers WHERE email = 'demo@greenwood.edu';
    
    -- Insert demo classes
    INSERT INTO classes (name, grade, section, teacher_id, academic_year) VALUES 
    ('Nursery A', 'Nursery', 'A', sarah_id, '2024-25'),
    ('5th Grade B', '5th', 'B', sarah_id, '2024-25'),
    ('1st Grade C', '1st', 'C', emily_id, '2024-25'),
    ('3rd Grade A', '3rd', 'A', emily_id, '2024-25')
    ON CONFLICT DO NOTHING;
    
    SELECT id INTO nursery_id FROM classes WHERE name = 'Nursery A';
    SELECT id INTO fifth_id FROM classes WHERE name = '5th Grade B';
    SELECT id INTO first_id FROM classes WHERE name = '1st Grade C';
    SELECT id INTO third_id FROM classes WHERE name = '3rd Grade A';
    
    -- Insert demo students for Nursery A
    INSERT INTO students (roll_no, name, class_id, parent_name, parent_phone, parent_email, gender, date_of_birth) VALUES 
    (1, 'Aarav Sharma', nursery_id, 'Rajesh Sharma', '+1234567801', 'rajesh.sharma@email.com', 'male', '2019-03-15'),
    (2, 'Anaya Patel', nursery_id, 'Priya Patel', '+1234567802', 'priya.patel@email.com', 'female', '2019-05-22'),
    (3, 'Arjun Kumar', nursery_id, 'Suresh Kumar', '+1234567803', 'suresh.kumar@email.com', 'male', '2019-01-10'),
    (4, 'Diya Singh', nursery_id, 'Meera Singh', '+1234567804', 'meera.singh@email.com', 'female', '2019-07-08'),
    (5, 'Ishaan Gupta', nursery_id, 'Amit Gupta', '+1234567805', 'amit.gupta@email.com', 'male', '2019-04-18'),
    (6, 'Kavya Reddy', nursery_id, 'Lakshmi Reddy', '+1234567806', 'lakshmi.reddy@email.com', 'female', '2019-06-25'),
    (7, 'Aryan Joshi', nursery_id, 'Deepak Joshi', '+1234567807', 'deepak.joshi@email.com', 'male', '2019-02-14'),
    (8, 'Riya Agarwal', nursery_id, 'Sunita Agarwal', '+1234567808', 'sunita.agarwal@email.com', 'female', '2019-08-30')
    ON CONFLICT (class_id, roll_no) DO NOTHING;
    
    -- Insert demo students for 5th Grade B
    INSERT INTO students (roll_no, name, class_id, parent_name, parent_phone, parent_email, gender, date_of_birth) VALUES 
    (1, 'Aditi Verma', fifth_id, 'Rakesh Verma', '+1234567811', 'rakesh.verma@email.com', 'female', '2014-09-12'),
    (2, 'Rohan Joshi', fifth_id, 'Neha Joshi', '+1234567812', 'neha.joshi@email.com', 'male', '2014-11-05'),
    (3, 'Priya Agarwal', fifth_id, 'Vinod Agarwal', '+1234567813', 'vinod.agarwal@email.com', 'female', '2014-07-20'),
    (4, 'Karan Mehta', fifth_id, 'Pooja Mehta', '+1234567814', 'pooja.mehta@email.com', 'male', '2014-12-03'),
    (5, 'Sneha Reddy', fifth_id, 'Ravi Reddy', '+1234567815', 'ravi.reddy@email.com', 'female', '2014-10-15'),
    (6, 'Vikram Rao', fifth_id, 'Sita Rao', '+1234567816', 'sita.rao@email.com', 'male', '2014-08-28'),
    (7, 'Anisha Sharma', fifth_id, 'Manoj Sharma', '+1234567817', 'manoj.sharma@email.com', 'female', '2014-06-11'),
    (8, 'Dev Patel', fifth_id, 'Kiran Patel', '+1234567818', 'kiran.patel@email.com', 'male', '2014-04-07')
    ON CONFLICT (class_id, roll_no) DO NOTHING;
    
    -- Insert demo students for 1st Grade C
    INSERT INTO students (roll_no, name, class_id, parent_name, parent_phone, parent_email, gender, date_of_birth) VALUES 
    (1, 'Aisha Khan', first_id, 'Salim Khan', '+1234567821', 'salim.khan@email.com', 'female', '2018-01-20'),
    (2, 'Rahul Singh', first_id, 'Geeta Singh', '+1234567822', 'geeta.singh@email.com', 'male', '2018-03-15'),
    (3, 'Tara Gupta', first_id, 'Rohit Gupta', '+1234567823', 'rohit.gupta@email.com', 'female', '2018-05-10'),
    (4, 'Arjun Nair', first_id, 'Priya Nair', '+1234567824', 'priya.nair@email.com', 'male', '2018-02-28'),
    (5, 'Meera Jain', first_id, 'Sunil Jain', '+1234567825', 'sunil.jain@email.com', 'female', '2018-07-05')
    ON CONFLICT (class_id, roll_no) DO NOTHING;
    
    -- Insert demo schedules for Nursery A
    INSERT INTO schedules (class_id, period, subject, start_time, end_time, day_of_week, teacher_id) VALUES 
    (nursery_id, 1, 'English', '09:00', '09:40', 1, sarah_id),
    (nursery_id, 2, 'Math', '09:40', '10:20', 1, sarah_id),
    (nursery_id, 3, 'Art & Craft', '10:40', '11:20', 1, sarah_id),
    (nursery_id, 4, 'Play Time', '11:20', '12:00', 1, sarah_id),
    (nursery_id, 5, 'Story Time', '12:00', '12:40', 1, sarah_id)
    ON CONFLICT (class_id, period, day_of_week) DO NOTHING;
    
    -- Insert demo schedules for 5th Grade B
    INSERT INTO schedules (class_id, period, subject, start_time, end_time, day_of_week, teacher_id) VALUES 
    (fifth_id, 1, 'Mathematics', '09:00', '09:40', 1, sarah_id),
    (fifth_id, 2, 'English', '09:40', '10:20', 1, sarah_id),
    (fifth_id, 3, 'Science', '10:40', '11:20', 1, sarah_id),
    (fifth_id, 4, 'Social Studies', '11:20', '12:00', 1, sarah_id),
    (fifth_id, 5, 'Hindi', '12:00', '12:40', 1, sarah_id),
    (fifth_id, 6, 'Physical Education', '12:40', '13:20', 1, sarah_id)
    ON CONFLICT (class_id, period, day_of_week) DO NOTHING;
    
    -- Insert demo schedules for 1st Grade C
    INSERT INTO schedules (class_id, period, subject, start_time, end_time, day_of_week, teacher_id) VALUES 
    (first_id, 1, 'English', '09:00', '09:40', 1, emily_id),
    (first_id, 2, 'Math', '09:40', '10:20', 1, emily_id),
    (first_id, 3, 'Drawing', '10:40', '11:20', 1, emily_id),
    (first_id, 4, 'Games', '11:20', '12:00', 1, emily_id)
    ON CONFLICT (class_id, period, day_of_week) DO NOTHING;
    
    -- Insert some demo attendance records for today
    INSERT INTO attendance_records (student_id, class_id, teacher_id, date, period, subject, is_present, sms_sent) 
    SELECT s.id, s.class_id, c.teacher_id, CURRENT_DATE, 1, 'English', 
           CASE WHEN s.roll_no IN (3, 5) THEN false ELSE true END,
           CASE WHEN s.roll_no IN (3, 5) THEN true ELSE false END
    FROM students s 
    JOIN classes c ON s.class_id = c.id 
    WHERE c.name = 'Nursery A'
    ON CONFLICT (student_id, date, period) DO NOTHING;
    
    INSERT INTO attendance_records (student_id, class_id, teacher_id, date, period, subject, is_present, sms_sent) 
    SELECT s.id, s.class_id, c.teacher_id, CURRENT_DATE, 1, 'Mathematics', 
           CASE WHEN s.roll_no IN (3, 6) THEN false ELSE true END,
           CASE WHEN s.roll_no IN (3, 6) THEN true ELSE false END
    FROM students s 
    JOIN classes c ON s.class_id = c.id 
    WHERE c.name = '5th Grade B'
    ON CONFLICT (student_id, date, period) DO NOTHING;
    
END $$;
