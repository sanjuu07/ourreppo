import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { verifyJWT } from "./lib/auth"

// Protected routes that require authentication
const protectedRoutes = ["/api/classes", "/api/students", "/api/attendance", "/api/schedule", "/api/dashboard"]

// Admin-only routes
const adminRoutes = ["/api/admin"]

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl

  // Check if the route needs protection
  const isProtectedRoute = protectedRoutes.some((route) => pathname.startsWith(route))
  const isAdminRoute = adminRoutes.some((route) => pathname.startsWith(route))

  if (isProtectedRoute || isAdminRoute) {
    const token = request.cookies.get("auth-token")?.value

    if (!token) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 })
    }

    try {
      const payload = await verifyJWT(token)

      // Check admin access
      if (isAdminRoute && payload.role !== "admin") {
        return NextResponse.json({ error: "Admin access required" }, { status: 403 })
      }

      // Add user info to headers for API routes
      const requestHeaders = new Headers(request.headers)
      requestHeaders.set("x-user-id", payload.teacherId)
      requestHeaders.set("x-user-email", payload.email)
      requestHeaders.set("x-user-role", payload.role)

      return NextResponse.next({
        request: {
          headers: requestHeaders,
        },
      })
    } catch (error) {
      return NextResponse.json({ error: "Invalid token" }, { status: 401 })
    }
  }

  return NextResponse.next()
}

export const config = {
  matcher: ["/api/:path*"],
}

// BACKEND INTEGRATION: Enhanced Middleware Features
// - Implement rate limiting middleware for API protection
// - Add CORS middleware for cross-origin requests
// - Create request logging middleware for monitoring
// - Implement API versioning middleware
// - Add request validation middleware
// - Create caching middleware for performance
// - Implement security headers middleware
// - Add request/response compression middleware
// - Create API analytics middleware
// - Implement feature flag middleware
