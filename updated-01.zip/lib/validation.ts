import { z } from "zod"

// Authentication schemas
export const loginSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
})

export const teacherSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Invalid email address"),
  phone: z.string().optional(),
  role: z.enum(["teacher", "admin"]).default("teacher"),
  department: z.string().optional(),
})

// Class schemas
export const classSchema = z.object({
  name: z.string().min(1, "Class name is required"),
  grade: z.string().min(1, "Grade is required"),
  section: z.string().optional(),
  teacherId: z.string().uuid("Invalid teacher ID"),
  academicYear: z.string().default("2024-25"),
})

// Student schemas
export const studentSchema = z.object({
  rollNo: z.number().int().positive("Roll number must be positive"),
  name: z.string().min(2, "Name must be at least 2 characters"),
  classId: z.string().uuid("Invalid class ID"),
  parentName: z.string().optional(),
  parentPhone: z.string().optional(),
  parentEmail: z.string().email().optional().or(z.literal("")),
  address: z.string().optional(),
  dateOfBirth: z.string().optional(),
  gender: z.enum(["male", "female", "other"]).optional(),
  bloodGroup: z.string().optional(),
})

// Attendance schemas
export const attendanceSubmissionSchema = z.object({
  classId: z.string().uuid("Invalid class ID"),
  period: z.number().int().min(1).max(10, "Period must be between 1 and 10"),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Invalid date format"),
  subject: z.string().optional(),
  attendanceData: z.array(
    z.object({
      studentId: z.string().uuid("Invalid student ID"),
      isPresent: z.boolean(),
      notes: z.string().optional(),
    }),
  ),
})

// Schedule schemas
export const scheduleSchema = z.object({
  classId: z.string().uuid("Invalid class ID"),
  period: z.number().int().min(1).max(10),
  subject: z.string().min(1, "Subject is required"),
  startTime: z.string().regex(/^\d{2}:\d{2}$/, "Invalid time format"),
  endTime: z.string().regex(/^\d{2}:\d{2}$/, "Invalid time format"),
  dayOfWeek: z.number().int().min(0).max(6),
  teacherId: z.string().uuid("Invalid teacher ID"),
  roomNumber: z.string().optional(),
})

// Query parameter schemas
export const paginationSchema = z.object({
  page: z.string().transform(Number).pipe(z.number().int().min(1)).default("1"),
  limit: z.string().transform(Number).pipe(z.number().int().min(1).max(100)).default("10"),
})

export const dateRangeSchema = z.object({
  startDate: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/)
    .optional(),
  endDate: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/)
    .optional(),
})

// Validation helper
export function validateRequest<T>(
  schema: z.ZodSchema<T>,
  data: unknown,
): {
  success: boolean
  data?: T
  errors?: string[]
} {
  try {
    const result = schema.parse(data)
    return { success: true, data: result }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return {
        success: false,
        errors: error.errors.map((err) => `${err.path.join(".")}: ${err.message}`),
      }
    }
    return { success: false, errors: ["Validation failed"] }
  }
}

// BACKEND INTEGRATION: Advanced Validation Features
// - Implement custom validation rules for school-specific requirements
// - Add file upload validation for images and documents
// - Create validation for academic year and semester constraints
// - Implement cross-field validation for complex business rules
// - Add validation for phone number formats by country
// - Create validation for academic calendar constraints
// - Implement validation for fee structure and payment rules
// - Add validation for exam and grade constraints
// - Create validation for library book management
// - Implement validation for transport route management
