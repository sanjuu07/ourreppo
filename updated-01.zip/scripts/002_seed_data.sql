-- Insert demo teacher
INSERT INTO teachers (email, name, phone, password_hash) VALUES 
('teacher@greenwood.edu', 'Mrs. Sarah Johnson', '+1234567890', '$2b$10$rQZ9QmjkQZ9QmjkQZ9QmjkQZ9QmjkQZ9QmjkQZ9QmjkQZ9QmjkQZ'),
('demo@greenwood.edu', 'Mr. John Smith', '+1234567891', '$2b$10$rQZ9QmjkQZ9QmjkQZ9QmjkQZ9QmjkQZ9QmjkQZ9QmjkQZ9QmjkQZ')
ON CONFLICT (email) DO NOTHING;

-- Get teacher IDs
DO $$
DECLARE
    sarah_id UUID;
    john_id UUID;
    nursery_id UUID;
    fifth_id UUID;
BEGIN
    SELECT id INTO sarah_id FROM teachers WHERE email = 'teacher@greenwood.edu';
    SELECT id INTO john_id FROM teachers WHERE email = 'demo@greenwood.edu';
    
    -- Insert demo classes
    INSERT INTO classes (name, grade, section, teacher_id) VALUES 
    ('Nursery A', 'Nursery', 'A', sarah_id),
    ('5th Grade B', '5th', 'B', sarah_id)
    ON CONFLICT DO NOTHING;
    
    SELECT id INTO nursery_id FROM classes WHERE name = 'Nursery A';
    SELECT id INTO fifth_id FROM classes WHERE name = '5th Grade B';
    
    -- Insert demo students for Nursery
    INSERT INTO students (roll_no, name, class_id, parent_phone, parent_email) VALUES 
    (1, 'Aarav Sharma', nursery_id, '+1234567801', 'parent1@email.com'),
    (2, 'Anaya Patel', nursery_id, '+1234567802', 'parent2@email.com'),
    (3, 'Arjun Kumar', nursery_id, '+1234567803', 'parent3@email.com'),
    (4, 'Diya Singh', nursery_id, '+1234567804', 'parent4@email.com'),
    (5, 'Ishaan Gupta', nursery_id, '+1234567805', 'parent5@email.com')
    ON CONFLICT (class_id, roll_no) DO NOTHING;
    
    -- Insert demo students for 5th Grade
    INSERT INTO students (roll_no, name, class_id, parent_phone, parent_email) VALUES 
    (1, 'Aditi Verma', fifth_id, '+1234567811', 'parent11@email.com'),
    (2, 'Rohan Joshi', fifth_id, '+1234567812', 'parent12@email.com'),
    (3, 'Priya Agarwal', fifth_id, '+1234567813', 'parent13@email.com'),
    (4, 'Karan Mehta', fifth_id, '+1234567814', 'parent14@email.com'),
    (5, 'Sneha Reddy', fifth_id, '+1234567815', 'parent15@email.com'),
    (6, 'Vikram Rao', fifth_id, '+1234567816', 'parent16@email.com')
    ON CONFLICT (class_id, roll_no) DO NOTHING;
    
    -- Insert demo schedules for Nursery
    INSERT INTO schedules (class_id, period, subject, start_time, end_time, day_of_week) VALUES 
    (nursery_id, 1, 'English', '09:00', '09:40', 1),
    (nursery_id, 2, 'Math', '09:40', '10:20', 1),
    (nursery_id, 3, 'Art', '10:40', '11:20', 1),
    (nursery_id, 4, 'Play Time', '11:20', '12:00', 1)
    ON CONFLICT DO NOTHING;
    
    -- Insert demo schedules for 5th Grade
    INSERT INTO schedules (class_id, period, subject, start_time, end_time, day_of_week) VALUES 
    (fifth_id, 1, 'Mathematics', '09:00', '09:40', 1),
    (fifth_id, 2, 'English', '09:40', '10:20', 1),
    (fifth_id, 3, 'Science', '10:40', '11:20', 1),
    (fifth_id, 4, 'Social Studies', '11:20', '12:00', 1),
    (fifth_id, 5, 'Hindi', '12:00', '12:40', 1)
    ON CONFLICT DO NOTHING;
END $$;
