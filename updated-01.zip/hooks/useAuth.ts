"use client"

import { useState, useEffect } from "react"

interface Teacher {
  id: string
  email: string
  name: string
  role: string
  phone?: string
  department?: string
  lastLoginAt?: string
}

export function useAuth() {
  const [teacher, setTeacher] = useState<Teacher | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    checkAuth()
  }, [])

  const checkAuth = async () => {
    try {
      const response = await fetch("/api/auth/me")
      if (response.ok) {
        const data = await response.json()
        setTeacher(data.teacher)
      }
    } catch (error) {
      console.error("Auth check failed:", error)
    } finally {
      setLoading(false)
    }
  }

  const login = async (email: string, password: string) => {
    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      })

      if (response.ok) {
        const data = await response.json()
        setTeacher(data.teacher)
        return { success: true }
      }

      // Handle error response
      let errorMessage = "Login failed"
      try {
        const err = await response.clone().json()
        errorMessage = err?.error ?? errorMessage
      } catch {
        const text = await response.text()
        if (text) errorMessage = text
      }
      return { success: false, error: errorMessage }
    } catch (error) {
      return { success: false, error: "Network error. Please try again." }
    }
  }

  const logout = async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST" })
      setTeacher(null)
    } catch (error) {
      console.error("Logout error:", error)
      setTeacher(null) // Force logout on error
    }
  }

  return {
    teacher,
    loading,
    login,
    logout,
    isAuthenticated: !!teacher,
    checkAuth,
  }
}

// FRONTEND INTEGRATION: Enhanced Authentication Features
// - Implement automatic token refresh
// - Add biometric authentication support
// - Create offline authentication capabilities
// - Implement social login integration
// - Add password strength indicator
// - Create login analytics and monitoring
// - Implement device management and security
// - Add login customization and branding
