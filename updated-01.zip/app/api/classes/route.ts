import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"
import { validateRequest, classSchema, paginationSchema } from "@/lib/validation"
import { createAuditLog } from "@/lib/audit"

export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const { page, limit } = validateRequest(paginationSchema, Object.fromEntries(searchParams)).data || {
      page: 1,
      limit: 10,
    }

    const offset = (page - 1) * limit

    // BACKEND INTEGRATION: Enhanced Class Management
    // - Add class capacity management and enrollment limits
    // - Implement class scheduling conflict detection
    // - Add class resource allocation (rooms, equipment)
    // - Create class performance analytics and reporting
    // - Implement class grouping and batch operations
    // - Add class archive and restore functionality
    // - Create class template system for quick setup

    // Get classes based on user role
    let classesQuery
    let countQuery

    if (user.role === "admin") {
      // Admin can see all classes
      classesQuery = sql`
        SELECT c.*, t.name as teacher_name, 
               COUNT(s.id) as student_count
        FROM classes c
        LEFT JOIN teachers t ON c.teacher_id = t.id
        LEFT JOIN students s ON c.id = s.class_id AND s.is_active = true
        WHERE c.is_active = true
        GROUP BY c.id, t.name
        ORDER BY c.grade, c.section
        LIMIT ${limit} OFFSET ${offset}
      `
      countQuery = sql`SELECT COUNT(*) as total FROM classes WHERE is_active = true`
    } else {
      // Teachers can only see their classes
      classesQuery = sql`
        SELECT c.*, t.name as teacher_name,
               COUNT(s.id) as student_count
        FROM classes c
        LEFT JOIN teachers t ON c.teacher_id = t.id
        LEFT JOIN students s ON c.id = s.class_id AND s.is_active = true
        WHERE c.teacher_id = ${user.teacherId} AND c.is_active = true
        GROUP BY c.id, t.name
        ORDER BY c.grade, c.section
        LIMIT ${limit} OFFSET ${offset}
      `
      countQuery = sql`
        SELECT COUNT(*) as total 
        FROM classes 
        WHERE teacher_id = ${user.teacherId} AND is_active = true
      `
    }

    const [classes, countResult] = await Promise.all([classesQuery, countQuery])

    const total = Number(countResult[0].total)
    const totalPages = Math.ceil(total / limit)

    return NextResponse.json({
      success: true,
      data: classes,
      pagination: {
        page,
        limit,
        total,
        totalPages,
      },
    })
  } catch (error) {
    console.error("Classes fetch error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user || user.role !== "admin") {
      return NextResponse.json({ error: "Admin access required" }, { status: 403 })
    }

    const body = await request.json()
    const validation = validateRequest(classSchema, body)

    if (!validation.success) {
      return NextResponse.json({ error: "Validation failed", details: validation.errors }, { status: 400 })
    }

    const { name, grade, section, teacherId, academicYear } = validation.data

    const [newClass] = await sql`
      INSERT INTO classes (name, grade, section, teacher_id, academic_year)
      VALUES (${name}, ${grade}, ${section}, ${teacherId}, ${academicYear})
      RETURNING *
    `

    await createAuditLog({
      action: "create_class",
      resourceType: "class",
      resourceId: newClass.id,
      newValues: newClass,
    })

    return NextResponse.json({
      success: true,
      data: newClass,
      message: "Class created successfully",
    })
  } catch (error) {
    console.error("Class creation error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
