import { type NextRequest, NextResponse } from "next/server"
import { getCurrentUser } from "@/lib/auth"
import { sql } from "@/lib/db"

export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser()

    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 })
    }

    // Get fresh user data
    const teachers = await sql`
      SELECT id, email, name, role, phone, department, last_login_at
      FROM teachers 
      WHERE id = ${user.teacherId} AND is_active = true
    `

    if (teachers.length === 0) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    const teacher = teachers[0]

    return NextResponse.json({
      teacher: {
        id: teacher.id,
        email: teacher.email,
        name: teacher.name,
        role: teacher.role,
        phone: teacher.phone,
        department: teacher.department,
        lastLoginAt: teacher.last_login_at,
      },
    })
  } catch (error) {
    console.error("Get user error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

// BACKEND INTEGRATION: Enhanced User Profile Features
// - Add user preference management
// - Implement profile photo upload and management
// - Add user activity tracking and analytics
// - Create user notification preferences
// - Implement user role and permission management
// - Add user session management across devices
