import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import { comparePassword, signJWT } from "@/lib/auth"
import { validateRequest, loginSchema } from "@/lib/validation"
import { createAuditLog } from "@/lib/audit"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const validation = validateRequest(loginSchema, body)

    if (!validation.success) {
      return NextResponse.json({ error: "Validation failed", details: validation.errors }, { status: 400 })
    }

    const { email, password } = validation.data

    // BACKEND INTEGRATION: Enhanced Login Security
    // - Implement rate limiting for login attempts
    // - Add CAPTCHA verification after failed attempts
    // - Implement account lockout mechanism
    // - Add device fingerprinting for security
    // - Implement geolocation-based login alerts
    // - Add multi-factor authentication support
    // - Create login attempt monitoring and alerts

    // Find teacher by email
    const teachers = await sql`
      SELECT id, email, name, password_hash, role, phone, department, is_active
      FROM teachers 
      WHERE email = ${email} AND is_active = true
    `

    if (teachers.length === 0) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
    }

    const teacher = teachers[0]

    // Verify password
    const isValidPassword = await comparePassword(password, teacher.password_hash)

    if (!isValidPassword) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
    }

    // Update last login
    await sql`
      UPDATE teachers 
      SET last_login_at = NOW() 
      WHERE id = ${teacher.id}
    `

    // Create JWT token
    const token = await signJWT({
      teacherId: teacher.id,
      email: teacher.email,
      name: teacher.name,
      role: teacher.role,
    })

    // Create audit log
    await createAuditLog({
      action: "login",
      resourceType: "auth",
      ipAddress: request.ip,
      userAgent: request.headers.get("user-agent") || undefined,
    })

    const response = NextResponse.json({
      success: true,
      teacher: {
        id: teacher.id,
        email: teacher.email,
        name: teacher.name,
        role: teacher.role,
        phone: teacher.phone,
        department: teacher.department,
      },
    })

    // Set HTTP-only cookie
    response.cookies.set("auth-token", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      maxAge: 86400, // 24 hours
      path: "/",
    })

    return response
  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
