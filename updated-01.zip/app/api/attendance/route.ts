import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"
import { validateRequest, attendanceSubmissionSchema } from "@/lib/validation"
import { createAuditLog } from "@/lib/audit"
import { sendBulkAbsenteesSMS } from "@/lib/sms"

export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const validation = validateRequest(attendanceSubmissionSchema, body)

    if (!validation.success) {
      return NextResponse.json({ error: "Validation failed", details: validation.errors }, { status: 400 })
    }

    const { classId, period, date, subject, attendanceData } = validation.data

    // BACKEND INTEGRATION: Enhanced Attendance Features
    // - Implement biometric attendance integration
    // - Add QR code-based attendance marking
    // - Create attendance analytics and insights
    // - Implement attendance prediction algorithms
    // - Add attendance pattern analysis
    // - Create attendance intervention alerts
    // - Implement attendance gamification features
    // - Add attendance integration with parent apps
    // - Create attendance-based fee discounts
    // - Implement attendance certificate generation

    // Verify user has access to this class
    if (user.role !== "admin") {
      const classAccess = await sql`
        SELECT id FROM classes 
        WHERE id = ${classId} AND teacher_id = ${user.teacherId} AND is_active = true
      `

      if (classAccess.length === 0) {
        return NextResponse.json({ error: "Access denied to this class" }, { status: 403 })
      }
    }

    // Begin transaction
    await sql.begin(async (sql) => {
      // Delete existing attendance for this class, period, and date
      await sql`
        DELETE FROM attendance_records 
        WHERE class_id = ${classId} AND period = ${period} AND date = ${date}
      `

      // Insert new attendance records
      for (const record of attendanceData) {
        await sql`
          INSERT INTO attendance_records (
            student_id, class_id, teacher_id, date, period, subject, 
            is_present, notes, marked_at
          )
          VALUES (
            ${record.studentId}, ${classId}, ${user.teacherId}, ${date}, ${period}, 
            ${subject}, ${record.isPresent}, ${record.notes}, NOW()
          )
        `
      }
    })

    // Get absent students for SMS
    const absentStudents = await sql`
      SELECT 
        s.id as student_id,
        s.name as student_name,
        s.parent_phone,
        c.name as class_name,
        ar.date,
        ar.period
      FROM attendance_records ar
      JOIN students s ON ar.student_id = s.id
      JOIN classes c ON ar.class_id = c.id
      WHERE ar.class_id = ${classId} 
        AND ar.period = ${period} 
        AND ar.date = ${date}
        AND ar.is_present = false
        AND s.parent_phone IS NOT NULL
        AND s.parent_phone != ''
    `

    // Send SMS notifications
    let smsResults = { sent: 0, failed: 0, results: [] }
    if (absentStudents.length > 0) {
      smsResults = await sendBulkAbsenteesSMS(
        absentStudents.map((student) => ({
          studentId: student.student_id,
          studentName: student.student_name,
          parentPhone: student.parent_phone,
          className: student.class_name,
          teacherId: user.teacherId,
          date: student.date,
          period: student.period,
        })),
      )

      // Update SMS sent status
      await sql`
        UPDATE attendance_records 
        SET sms_sent = true, sms_sent_at = NOW()
        WHERE class_id = ${classId} 
          AND period = ${period} 
          AND date = ${date}
          AND is_present = false
          AND student_id IN (${absentStudents.map((s) => s.student_id)})
      `
    }

    await createAuditLog({
      action: "submit_attendance",
      resourceType: "attendance",
      newValues: {
        classId,
        period,
        date,
        totalStudents: attendanceData.length,
        presentCount: attendanceData.filter((r) => r.isPresent).length,
        absentCount: attendanceData.filter((r) => !r.isPresent).length,
      },
    })

    return NextResponse.json({
      success: true,
      message: `Attendance saved successfully. SMS sent to ${smsResults.sent} parents.`,
      data: {
        totalStudents: attendanceData.length,
        presentCount: attendanceData.filter((r) => r.isPresent).length,
        absentCount: attendanceData.filter((r) => !r.isPresent).length,
        smsSent: smsResults.sent,
        smsFailed: smsResults.failed,
      },
    })
  } catch (error) {
    console.error("Attendance submission error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const classId = searchParams.get("classId")
    const date = searchParams.get("date")
    const period = searchParams.get("period")

    if (!classId || !date || !period) {
      return NextResponse.json({ error: "Missing required parameters" }, { status: 400 })
    }

    // Verify user has access to this class
    if (user.role !== "admin") {
      const classAccess = await sql`
        SELECT id FROM classes 
        WHERE id = ${classId} AND teacher_id = ${user.teacherId} AND is_active = true
      `

      if (classAccess.length === 0) {
        return NextResponse.json({ error: "Access denied to this class" }, { status: 403 })
      }
    }

    const attendance = await sql`
      SELECT 
        ar.*,
        s.name as student_name,
        s.roll_no,
        s.parent_phone,
        s.parent_email
      FROM attendance_records ar
      JOIN students s ON ar.student_id = s.id
      WHERE ar.class_id = ${classId}
        AND ar.date = ${date}
        AND ar.period = ${Number.parseInt(period)}
      ORDER BY s.roll_no
    `

    return NextResponse.json({
      success: true,
      data: attendance,
    })
  } catch (error) {
    console.error("Attendance fetch error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
