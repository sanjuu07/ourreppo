import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"
import { validateRequest, scheduleSchema } from "@/lib/validation"
import { createAuditLog } from "@/lib/audit"

export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const classId = searchParams.get("classId")
    const dayOfWeek = searchParams.get("dayOfWeek") || "1" // Default to Monday

    if (!classId) {
      return NextResponse.json({ error: "Class ID is required" }, { status: 400 })
    }

    // BACKEND INTEGRATION: Enhanced Schedule Management
    // - Implement schedule conflict detection and resolution
    // - Add schedule optimization algorithms
    // - Create schedule template system
    // - Implement schedule change notifications
    // - Add schedule integration with calendar systems
    // - Create schedule analytics and utilization reports
    // - Implement schedule backup and recovery
    // - Add schedule mobile synchronization
    // - Create schedule resource allocation management
    // - Implement schedule performance monitoring

    // Verify user has access to this class
    if (user.role !== "admin") {
      const classAccess = await sql`
        SELECT id FROM classes 
        WHERE id = ${classId} AND teacher_id = ${user.teacherId} AND is_active = true
      `

      if (classAccess.length === 0) {
        return NextResponse.json({ error: "Access denied to this class" }, { status: 403 })
      }
    }

    const schedule = await sql`
      SELECT 
        s.*,
        t.name as teacher_name,
        c.name as class_name
      FROM schedules s
      LEFT JOIN teachers t ON s.teacher_id = t.id
      JOIN classes c ON s.class_id = c.id
      WHERE s.class_id = ${classId}
        AND s.day_of_week = ${Number.parseInt(dayOfWeek)}
        AND s.is_active = true
      ORDER BY s.period
    `

    return NextResponse.json({
      success: true,
      data: schedule,
    })
  } catch (error) {
    console.error("Schedule fetch error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user || user.role !== "admin") {
      return NextResponse.json({ error: "Admin access required" }, { status: 403 })
    }

    const body = await request.json()
    const validation = validateRequest(scheduleSchema, body)

    if (!validation.success) {
      return NextResponse.json({ error: "Validation failed", details: validation.errors }, { status: 400 })
    }

    const { classId, period, subject, startTime, endTime, dayOfWeek, teacherId, roomNumber } = validation.data

    // Check for conflicts
    const conflicts = await sql`
      SELECT id FROM schedules
      WHERE class_id = ${classId}
        AND period = ${period}
        AND day_of_week = ${dayOfWeek}
        AND is_active = true
    `

    if (conflicts.length > 0) {
      return NextResponse.json({ error: "Schedule conflict: Period already exists" }, { status: 400 })
    }

    const [newSchedule] = await sql`
      INSERT INTO schedules (
        class_id, period, subject, start_time, end_time, 
        day_of_week, teacher_id, room_number
      )
      VALUES (
        ${classId}, ${period}, ${subject}, ${startTime}, ${endTime},
        ${dayOfWeek}, ${teacherId}, ${roomNumber}
      )
      RETURNING *
    `

    await createAuditLog({
      action: "create_schedule",
      resourceType: "schedule",
      resourceId: newSchedule.id,
      newValues: newSchedule,
    })

    return NextResponse.json({
      success: true,
      data: newSchedule,
      message: "Schedule created successfully",
    })
  } catch (error) {
    console.error("Schedule creation error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
