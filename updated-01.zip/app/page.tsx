"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { UserCheck, GraduationCap, Loader2, BarChart3, Settings } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useAuth } from "@/hooks/useAuth"
import { useClasses } from "@/hooks/useClasses"
import { useStudents } from "@/hooks/useStudents"
import { useDashboard } from "@/hooks/useDashboard"

// FRONTEND INTEGRATION: Enhanced UI Components
// - Implement dark mode support
// - Add accessibility features (ARIA labels, keyboard navigation)
// - Create responsive design for all screen sizes
// - Implement progressive web app (PWA) features
// - Add offline functionality and data synchronization
// - Create custom loading and error states
// - Implement drag and drop functionality
// - Add animation and transition effects
// - Create print-friendly layouts
// - Implement internationalization (i18n) support

interface AttendanceRecord {
  studentId: string
  isPresent: boolean
  notes?: string
}

interface Schedule {
  id: string
  period: number
  subject: string
  start_time: string
  end_time: string
  teacher_name?: string
  room_number?: string
}

interface Absentee {
  student_name: string
  roll_no: number
  date: string
  class_name: string
  period: number
  subject?: string
  sms_sent: boolean
  sms_status?: string
  notes?: string
}

export default function TeacherDashboard() {
  const { teacher, loading: authLoading, login, logout, isAuthenticated } = useAuth()
  const { classes, loading: classesLoading, error: classesError } = useClasses()
  const { stats, loading: statsLoading, refetch: refetchStats } = useDashboard()

  const [currentPage, setCurrentPage] = useState("home")
  const [selectedClassId, setSelectedClassId] = useState<string>("")
  const [selectedPeriod, setSelectedPeriod] = useState("")
  const [showSMSModal, setShowSMSModal] = useState(false)
  const [submissionResult, setSubmissionResult] = useState<any>(null)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [schedule, setSchedule] = useState<Schedule[]>([])
  const [absentees, setAbsentees] = useState<Absentee[]>([])
  const [attendanceData, setAttendanceData] = useState<Record<string, { isPresent: boolean; notes?: string }>>({})
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const { students, loading: studentsLoading, error: studentsError } = useStudents(selectedClassId)

  // Fetch schedule when class is selected
  useEffect(() => {
    if (selectedClassId) {
      fetchSchedule(selectedClassId)
    }
  }, [selectedClassId])

  // Fetch absentees when authenticated
  useEffect(() => {
    if (isAuthenticated) {
      fetchAbsentees()
    }
  }, [isAuthenticated])

  // Initialize attendance data when students change
  useEffect(() => {
    if (students.length > 0) {
      const initialData: Record<string, { isPresent: boolean; notes?: string }> = {}
      students.forEach((student) => {
        initialData[student.id] = { isPresent: true } // Default to present
      })
      setAttendanceData(initialData)
    }
  }, [students])

  const fetchSchedule = async (classId: string) => {
    try {
      const response = await fetch(`/api/schedule?classId=${classId}`)
      const data = await response.json()

      if (data.success) {
        setSchedule(data.data)
      } else {
        console.error("Failed to fetch schedule:", data.error)
      }
    } catch (error) {
      console.error("Failed to fetch schedule:", error)
    }
  }

  const fetchAbsentees = async () => {
    try {
      const response = await fetch("/api/absentees")
      const data = await response.json()

      if (data.success) {
        setAbsentees(data.data)
      } else {
        console.error("Failed to fetch absentees:", data.error)
      }
    } catch (error) {
      console.error("Failed to fetch absentees:", error)
    }
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)

    const formData = new FormData(e.target as HTMLFormElement)
    const email = formData.get("email") as string
    const password = formData.get("password") as string

    const result = await login(email, password)
    if (!result.success) {
      setError(result.error || "Login failed")
    }
  }

  const handleLogout = async () => {
    await logout()
    setCurrentPage("home")
  }

  const toggleAttendance = (studentId: string) => {
    setAttendanceData((prev) => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        isPresent: !prev[studentId]?.isPresent,
      },
    }))
  }

  const updateNotes = (studentId: string, notes: string) => {
    setAttendanceData((prev) => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        notes,
      },
    }))
  }

  const markAllPresent = () => {
    const newData: Record<string, { isPresent: boolean; notes?: string }> = {}
    students.forEach((student) => {
      newData[student.id] = { isPresent: true, notes: attendanceData[student.id]?.notes }
    })
    setAttendanceData(newData)
  }

  const markAllAbsent = () => {
    const newData: Record<string, { isPresent: boolean; notes?: string }> = {}
    students.forEach((student) => {
      newData[student.id] = { isPresent: false, notes: attendanceData[student.id]?.notes }
    })
    setAttendanceData(newData)
  }

  const handleAttendanceSubmit = async () => {
    if (!selectedClassId || !selectedPeriod) {
      setError("Please select class and period")
      return
    }

    setSubmitting(true)
    setError(null)

    try {
      const attendanceRecords: AttendanceRecord[] = Object.entries(attendanceData).map(([studentId, data]) => ({
        studentId,
        isPresent: data.isPresent,
        notes: data.notes,
      }))

      const response = await fetch("/api/attendance", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          classId: selectedClassId,
          period: Number.parseInt(selectedPeriod),
          attendanceData: attendanceRecords,
          date: new Date().toISOString().split("T")[0],
          subject: schedule.find((s) => s.period === Number.parseInt(selectedPeriod))?.subject,
        }),
      })

      const data = await response.json()

      if (data.success) {
        setSubmissionResult(data.data)
        setShowSMSModal(true)
        refetchStats() // Refresh dashboard stats
        fetchAbsentees() // Refresh absentees
      } else {
        setError(data.error || "Failed to submit attendance")
      }
    } catch (error) {
      console.error("Failed to submit attendance:", error)
      setError("Network error. Please try again.")
    } finally {
      setSubmitting(false)
    }
  }

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-cyan-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-blue-600" />
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    )
  }

  // Login Page
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-cyan-50 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <Card className="shadow-2xl border-0 bg-white/80 backdrop-blur-sm">
            <CardHeader className="text-center space-y-6 pb-8">
              <div className="mx-auto w-20 h-20 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-2xl flex items-center justify-center shadow-lg">
                <GraduationCap className="w-10 h-10 text-white" />
              </div>
              <div className="space-y-2">
                <CardTitle className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                  Greenwood School
                </CardTitle>
                <CardDescription className="text-gray-600 text-lg">Teacher Portal</CardDescription>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {error && (
                <Alert className="border-red-200 bg-red-50">
                  <AlertDescription className="text-red-700">{error}</AlertDescription>
                </Alert>
              )}
              <form onSubmit={handleLogin} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-sm font-medium text-gray-700">
                    Email Address
                  </Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="teacher@greenwood.edu"
                    required
                    className="h-12 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password" className="text-sm font-medium text-gray-700">
                    Password
                  </Label>
                  <Input
                    id="password"
                    name="password"
                    type="password"
                    placeholder="Enter your password"
                    required
                    className="h-12 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                <Button
                  type="submit"
                  className="w-full h-12 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-medium rounded-lg shadow-lg hover:shadow-xl transition-all duration-200"
                >
                  Sign In to Dashboard
                </Button>
              </form>
              <div className="text-center text-sm text-gray-600 bg-blue-50 p-4 rounded-lg">
                <p className="font-medium mb-2">Demo Credentials:</p>
                <p>Email: teacher@greenwood.edu</p>
                <p>Password: teacher123</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  // Main Dashboard Content
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50/30">
      {/* Your existing dashboard JSX continues here... */}
      <div className="text-center py-20">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Welcome to Greenwood School Teacher Dashboard</h1>
        <p className="text-xl text-gray-600 mb-8">Complete production-ready teacher management system</p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          <Card>
            <CardContent className="p-6 text-center">
              <UserCheck className="w-12 h-12 mx-auto mb-4 text-green-600" />
              <h3 className="text-lg font-semibold mb-2">Attendance Management</h3>
              <p className="text-gray-600">Easy one-click attendance with SMS notifications</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <BarChart3 className="w-12 h-12 mx-auto mb-4 text-blue-600" />
              <h3 className="text-lg font-semibold mb-2">Analytics & Reports</h3>
              <p className="text-gray-600">Comprehensive reporting and insights</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <Settings className="w-12 h-12 mx-auto mb-4 text-purple-600" />
              <h3 className="text-lg font-semibold mb-2">Admin Panel</h3>
              <p className="text-gray-600">Complete school management system</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

// FRONTEND INTEGRATION: Complete Dashboard Implementation
// - Implement all dashboard pages (attendance, schedule, reports, etc.)
// - Add real-time updates and notifications
// - Create mobile-responsive design
// - Implement offline functionality
// - Add data visualization and charts
// - Create export and print functionality
// - Implement search and filtering
// - Add keyboard shortcuts and accessibility
// - Create custom themes and personalization
// - Implement progressive web app features
