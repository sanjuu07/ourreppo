"use client"

import type React from "react"
import { useState } from "react"
import {
  Calendar,
  Users,
  UserCheck,
  UserX,
  Clock,
  Bell,
  LogOut,
  Home,
  Eye,
  Check,
  X,
  Menu,
  GraduationCap,
  TrendingUp,
  Award,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import {
  Sidebar,
  SidebarGroup,
  SidebarGroupContent,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar"

// Mock data
const classes = ["Nursery", "LKG", "UKG", "1st", "2nd", "3rd", "4th", "5th", "6th", "7th", "8th", "9th", "10th"]

const scheduleData = {
  Nursery: [
    { period: 1, subject: "English", time: "9:00 - 9:40" },
    { period: 2, subject: "Math", time: "9:40 - 10:20" },
    { period: 3, subject: "Art", time: "10:40 - 11:20" },
    { period: 4, subject: "Play Time", time: "11:20 - 12:00" },
  ],
  "5th": [
    { period: 1, subject: "Mathematics", time: "9:00 - 9:40" },
    { period: 2, subject: "English", time: "9:40 - 10:20" },
    { period: 3, subject: "Science", time: "10:40 - 11:20" },
    { period: 4, subject: "Social Studies", time: "11:20 - 12:00" },
    { period: 5, subject: "Hindi", time: "12:00 - 12:40" },
  ],
}

const studentsData = {
  Nursery: [
    { rollNo: 1, name: "Aarav Sharma", present: true },
    { rollNo: 2, name: "Anaya Patel", present: true },
    { rollNo: 3, name: "Arjun Kumar", present: false },
    { rollNo: 4, name: "Diya Singh", present: true },
    { rollNo: 5, name: "Ishaan Gupta", present: false },
  ],
  "5th": [
    { rollNo: 1, name: "Aditi Verma", present: true },
    { rollNo: 2, name: "Rohan Joshi", present: true },
    { rollNo: 3, name: "Priya Agarwal", present: false },
    { rollNo: 4, name: "Karan Mehta", present: true },
    { rollNo: 5, name: "Sneha Reddy", present: true },
    { rollNo: 6, name: "Vikram Rao", present: false },
  ],
}

const absenteesData = [
  { name: "Arjun Kumar", rollNo: 1, date: "2024-01-23", class: "Nursery", smsStatus: "Sent" },
  { name: "Ishaan Gupta", rollNo: 5, date: "2024-01-23", class: "Nursery", smsStatus: "Sent" },
  { name: "Priya Agarwal", rollNo: 3, date: "2024-01-23", class: "5th", smsStatus: "Sent" },
  { name: "Vikram Rao", rollNo: 6, date: "2024-01-22", class: "5th", smsStatus: "Failed" },
]

export default function TeacherDashboard() {
  const [currentPage, setCurrentPage] = useState("login")
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [selectedClass, setSelectedClass] = useState("")
  const [selectedPeriod, setSelectedPeriod] = useState("")
  const [attendanceData, setAttendanceData] = useState({})
  const [showSMSModal, setShowSMSModal] = useState(false)
  const [absentCount, setAbsentCount] = useState(0)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoggedIn(true)
    setCurrentPage("home")
  }

  const handleLogout = () => {
    setIsLoggedIn(false)
    setCurrentPage("login")
  }

  const handleAttendanceSubmit = () => {
    const students = studentsData[selectedClass as keyof typeof studentsData] || []
    const absentStudents = students.filter((student) => !student.present).length
    setAbsentCount(absentStudents)
    setShowSMSModal(true)
  }

  const toggleAttendance = (rollNo: number) => {
    const students = studentsData[selectedClass as keyof typeof studentsData] || []
    const studentIndex = students.findIndex((s) => s.rollNo === rollNo)
    if (studentIndex !== -1) {
      students[studentIndex].present = !students[studentIndex].present
      setAttendanceData({ ...attendanceData })
    }
  }

  // Login Page
  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-cyan-50 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <Card className="shadow-2xl border-0 bg-white/80 backdrop-blur-sm">
            <CardHeader className="text-center space-y-6 pb-8">
              <div className="mx-auto w-20 h-20 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-2xl flex items-center justify-center shadow-lg">
                <GraduationCap className="w-10 h-10 text-white" />
              </div>
              <div className="space-y-2">
                <CardTitle className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                  Greenwood School
                </CardTitle>
                <CardDescription className="text-gray-600 text-lg">Teacher Portal</CardDescription>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <form onSubmit={handleLogin} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-sm font-medium text-gray-700">
                    Email Address
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="teacher@greenwood.edu"
                    required
                    className="h-12 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password" className="text-sm font-medium text-gray-700">
                    Password
                  </Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="Enter your password"
                    required
                    className="h-12 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                <Button
                  type="submit"
                  className="w-full h-12 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-medium rounded-lg shadow-lg hover:shadow-xl transition-all duration-200"
                >
                  Sign In to Dashboard
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  // Sidebar Navigation
  const sidebarItems = [
    { icon: Home, label: "Dashboard", page: "home" },
    { icon: UserCheck, label: "Take Attendance", page: "attendance" },
    { icon: Eye, label: "View Absentees", page: "absentees" },
    { icon: Calendar, label: "Schedule", page: "schedule" },
  ]

  const SidebarContent = () => (
    <>
      <SidebarHeader className="border-b border-gray-100 p-6">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-xl flex items-center justify-center shadow-lg">
            <GraduationCap className="w-7 h-7 text-white" />
          </div>
          <div>
            <h2 className="font-bold text-gray-900 text-lg">Greenwood</h2>
            <p className="text-sm text-gray-500">Teacher Portal</p>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup className="px-4 py-6">
          <SidebarGroupContent>
            <SidebarMenu className="space-y-2">
              {sidebarItems.map((item) => (
                <SidebarMenuItem key={item.page}>
                  <SidebarMenuButton
                    onClick={() => {
                      setCurrentPage(item.page)
                      setIsMobileMenuOpen(false)
                    }}
                    isActive={currentPage === item.page}
                    className="w-full justify-start h-12 rounded-xl font-medium transition-all duration-200 hover:bg-blue-50 data-[active=true]:bg-gradient-to-r data-[active=true]:from-blue-600 data-[active=true]:to-indigo-600 data-[active=true]:text-white data-[active=true]:shadow-lg"
                  >
                    <item.icon className="w-5 h-5" />
                    <span>{item.label}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
              <SidebarMenuItem className="mt-8">
                <SidebarMenuButton
                  onClick={handleLogout}
                  className="w-full justify-start h-12 rounded-xl font-medium text-red-600 hover:text-red-700 hover:bg-red-50 transition-all duration-200"
                >
                  <LogOut className="w-5 h-5" />
                  <span>Logout</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </>
  )

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50/30">
      {/* Mobile Navigation */}
      <div className="lg:hidden">
        <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
          <div className="flex items-center justify-between p-4 bg-white border-b border-gray-200">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-lg flex items-center justify-center">
                <GraduationCap className="w-6 h-6 text-white" />
              </div>
              <h1 className="font-bold text-gray-900">Greenwood</h1>
            </div>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
          </div>
          <SheetContent side="left" className="p-0 w-80">
            <Sidebar className="border-0">
              <SidebarContent />
            </Sidebar>
          </SheetContent>
        </Sheet>
      </div>

      {/* Desktop Layout */}
      <div className="hidden lg:flex">
        <SidebarProvider>
          <Sidebar className="border-r border-gray-200 bg-white">
            <SidebarContent />
          </Sidebar>

          <SidebarInset className="flex-1">
            {/* Top Bar */}
            <header className="bg-white/80 backdrop-blur-sm border-b border-gray-200 px-4 lg:px-8 py-4 sticky top-0 z-10">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <SidebarTrigger className="lg:hidden" />
                  <div>
                    <h1 className="text-xl lg:text-2xl font-bold text-gray-900">
                      {currentPage === "home" && "Dashboard Overview"}
                      {currentPage === "attendance" && "Take Attendance"}
                      {currentPage === "absentees" && "View Absentees"}
                      {currentPage === "schedule" && "Class Schedule"}
                    </h1>
                    <p className="text-sm text-gray-500 hidden sm:block">
                      {new Date().toLocaleDateString("en-US", {
                        weekday: "long",
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                      })}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="hidden md:flex items-center space-x-3 bg-gradient-to-r from-blue-50 to-indigo-50 px-4 py-2 rounded-full">
                    <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-full flex items-center justify-center">
                      <span className="text-white text-sm font-medium">SJ</span>
                    </div>
                    <span className="text-sm font-medium text-gray-700">Mrs. Sarah Johnson</span>
                  </div>
                  <Button variant="ghost" size="icon" className="relative">
                    <Bell className="w-5 h-5 text-gray-600" />
                    <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></span>
                  </Button>
                </div>
              </div>
            </header>

            {/* Main Content */}
            <main className="p-4 lg:p-8">
              {/* Home Dashboard */}
              {currentPage === "home" && (
                <div className="space-y-6 lg:space-y-8">
                  {/* Welcome Section */}
                  <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 rounded-2xl p-6 lg:p-8 text-white relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16"></div>
                    <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full translate-y-12 -translate-x-12"></div>
                    <div className="relative z-10">
                      <h2 className="text-2xl lg:text-3xl font-bold mb-2">Welcome back, Mrs. Sarah! 👋</h2>
                      <p className="text-blue-100 text-lg">
                        Ready to inspire young minds today? Let's make learning magical!
                      </p>
                    </div>
                  </div>

                  {/* Stats Cards */}
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
                    <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200 hover:shadow-lg transition-all duration-200">
                      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium text-green-800">Present Today</CardTitle>
                        <div className="w-8 h-8 bg-green-500 rounded-lg flex items-center justify-center">
                          <UserCheck className="h-4 w-4 text-white" />
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl lg:text-3xl font-bold text-green-700">142</div>
                        <p className="text-xs text-green-600 flex items-center mt-1">
                          <TrendingUp className="w-3 h-3 mr-1" />
                          +5 from yesterday
                        </p>
                      </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-red-50 to-rose-50 border-red-200 hover:shadow-lg transition-all duration-200">
                      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium text-red-800">Absent Today</CardTitle>
                        <div className="w-8 h-8 bg-red-500 rounded-lg flex items-center justify-center">
                          <UserX className="h-4 w-4 text-white" />
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl lg:text-3xl font-bold text-red-700">8</div>
                        <p className="text-xs text-red-600 flex items-center mt-1">
                          <TrendingUp className="w-3 h-3 mr-1 rotate-180" />
                          -2 from yesterday
                        </p>
                      </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 border-blue-200 hover:shadow-lg transition-all duration-200">
                      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium text-blue-800">Total Classes</CardTitle>
                        <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center">
                          <Users className="h-4 w-4 text-white" />
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl lg:text-3xl font-bold text-blue-700">6</div>
                        <p className="text-xs text-blue-600">Nursery to 5th Grade</p>
                      </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-orange-50 to-amber-50 border-orange-200 hover:shadow-lg transition-all duration-200">
                      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium text-orange-800">Next Period</CardTitle>
                        <div className="w-8 h-8 bg-orange-500 rounded-lg flex items-center justify-center">
                          <Clock className="h-4 w-4 text-white" />
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl lg:text-3xl font-bold text-orange-700">10:40</div>
                        <p className="text-xs text-orange-600">5th Grade Math</p>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Quick Actions & Schedule */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-8">
                    <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
                      <CardHeader className="pb-4">
                        <CardTitle className="flex items-center space-x-2">
                          <Award className="w-5 h-5 text-blue-600" />
                          <span>Quick Class Selection</span>
                        </CardTitle>
                        <CardDescription>Jump to any class instantly</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <Select value={selectedClass} onValueChange={setSelectedClass}>
                          <SelectTrigger className="h-12 border-gray-200 focus:border-blue-500">
                            <SelectValue placeholder="Choose your class" />
                          </SelectTrigger>
                          <SelectContent>
                            {classes.map((cls) => (
                              <SelectItem key={cls} value={cls} className="py-3">
                                <div className="flex items-center space-x-2">
                                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                                  <span>{cls} Class</span>
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        {selectedClass && (
                          <div className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg">
                            <p className="text-sm font-medium text-blue-800">Selected: {selectedClass} Class</p>
                            <p className="text-xs text-blue-600 mt-1">Ready for attendance and schedule management</p>
                          </div>
                        )}
                      </CardContent>
                    </Card>

                    <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
                      <CardHeader className="pb-4">
                        <CardTitle className="flex items-center space-x-2">
                          <Clock className="w-5 h-5 text-indigo-600" />
                          <span>Today's Schedule</span>
                        </CardTitle>
                        <CardDescription>Your upcoming periods</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          <div className="flex justify-between items-center p-3 bg-gradient-to-r from-blue-50 to-blue-100 rounded-lg border-l-4 border-blue-500">
                            <div>
                              <span className="font-semibold text-blue-900">Period 3 - Science</span>
                              <p className="text-xs text-blue-700">Current Period</p>
                            </div>
                            <span className="text-sm font-medium text-blue-800">10:40 - 11:20</span>
                          </div>
                          <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg border-l-4 border-gray-300">
                            <div>
                              <span className="font-medium text-gray-700">Period 4 - Math</span>
                              <p className="text-xs text-gray-500">Next Up</p>
                            </div>
                            <span className="text-sm text-gray-600">11:20 - 12:00</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              )}

              {/* Schedule Page */}
              {currentPage === "schedule" && (
                <div className="space-y-6">
                  <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Calendar className="w-5 h-5 text-blue-600" />
                        <span>Class Schedule Management</span>
                      </CardTitle>
                      <CardDescription>View and manage class timetables with ease</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="mb-6">
                        <Label htmlFor="class-select" className="text-sm font-medium text-gray-700 mb-2 block">
                          Select Class
                        </Label>
                        <Select value={selectedClass} onValueChange={setSelectedClass}>
                          <SelectTrigger className="w-full lg:w-80 h-12 border-gray-200 focus:border-blue-500">
                            <SelectValue placeholder="Choose a class to view schedule" />
                          </SelectTrigger>
                          <SelectContent>
                            {classes.map((cls) => (
                              <SelectItem key={cls} value={cls} className="py-3">
                                <div className="flex items-center space-x-2">
                                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                                  <span>{cls} Class</span>
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      {selectedClass && scheduleData[selectedClass as keyof typeof scheduleData] && (
                        <div className="overflow-x-auto">
                          <Table>
                            <TableHeader>
                              <TableRow className="bg-gradient-to-r from-blue-50 to-indigo-50">
                                <TableHead className="font-semibold text-blue-900">Period</TableHead>
                                <TableHead className="font-semibold text-blue-900">Subject</TableHead>
                                <TableHead className="font-semibold text-blue-900">Time</TableHead>
                                <TableHead className="font-semibold text-blue-900">Action</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {scheduleData[selectedClass as keyof typeof scheduleData].map((period, index) => (
                                <TableRow
                                  key={period.period}
                                  className={index % 2 === 0 ? "bg-gray-50/50" : "bg-white"}
                                >
                                  <TableCell className="font-medium">
                                    <div className="flex items-center space-x-2">
                                      <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                                        <span className="text-blue-700 font-semibold text-sm">{period.period}</span>
                                      </div>
                                    </div>
                                  </TableCell>
                                  <TableCell className="font-medium text-gray-900">{period.subject}</TableCell>
                                  <TableCell className="text-gray-600">{period.time}</TableCell>
                                  <TableCell>
                                    <Button
                                      size="sm"
                                      onClick={() => {
                                        setSelectedPeriod(period.period.toString())
                                        setCurrentPage("attendance")
                                      }}
                                      className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white shadow-md hover:shadow-lg transition-all duration-200"
                                    >
                                      <UserCheck className="w-4 h-4 mr-2" />
                                      Take Attendance
                                    </Button>
                                  </TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              )}

              {/* Take Attendance Page */}
              {currentPage === "attendance" && (
                <div className="space-y-6">
                  <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2 text-2xl">
                        <UserCheck className="w-7 h-7 text-green-600" />
                        <span>Take Attendance</span>
                      </CardTitle>
                      <CardDescription className="text-lg">
                        Simple and quick attendance marking for your class
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      {/* Step 1: Class and Period Selection */}
                      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-xl mb-8">
                        <h3 className="text-xl font-semibold text-blue-900 mb-4">Step 1: Select Your Class & Period</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div className="space-y-3">
                            <Label htmlFor="class-select" className="text-lg font-medium text-gray-700">
                              Choose Class
                            </Label>
                            <Select value={selectedClass} onValueChange={setSelectedClass}>
                              <SelectTrigger className="h-16 text-lg border-2 border-gray-200 focus:border-blue-500">
                                <SelectValue placeholder="Select your class" />
                              </SelectTrigger>
                              <SelectContent>
                                {classes.map((cls) => (
                                  <SelectItem key={cls} value={cls} className="py-4 text-lg">
                                    <div className="flex items-center space-x-3">
                                      <div className="w-4 h-4 bg-blue-500 rounded-full"></div>
                                      <span className="font-medium">{cls} Class</span>
                                    </div>
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-3">
                            <Label htmlFor="period-select" className="text-lg font-medium text-gray-700">
                              Choose Period
                            </Label>
                            <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                              <SelectTrigger className="h-16 text-lg border-2 border-gray-200 focus:border-blue-500">
                                <SelectValue placeholder="Select period" />
                              </SelectTrigger>
                              <SelectContent>
                                {[1, 2, 3, 4, 5].map((period) => (
                                  <SelectItem key={period} value={period.toString()} className="py-4 text-lg">
                                    <div className="flex items-center space-x-3">
                                      <Clock className="w-4 h-4 text-orange-500" />
                                      <span className="font-medium">Period {period}</span>
                                    </div>
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                      </div>

                      {selectedClass && studentsData[selectedClass as keyof typeof studentsData] && (
                        <>
                          {/* Step 2: Quick Actions */}
                          <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-6 rounded-xl mb-8">
                            <h3 className="text-xl font-semibold text-green-900 mb-4">Step 2: Quick Actions</h3>
                            <div className="flex flex-col sm:flex-row gap-4">
                              <Button
                                onClick={() => {
                                  const students = studentsData[selectedClass as keyof typeof studentsData]
                                  students.forEach((student) => (student.present = true))
                                  setAttendanceData({ ...attendanceData })
                                }}
                                className="h-16 text-lg bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white shadow-lg hover:shadow-xl transition-all duration-200 flex-1"
                              >
                                <Check className="w-6 h-6 mr-3" />
                                Mark All Present
                              </Button>
                              <Button
                                onClick={() => {
                                  const students = studentsData[selectedClass as keyof typeof studentsData]
                                  students.forEach((student) => (student.present = false))
                                  setAttendanceData({ ...attendanceData })
                                }}
                                variant="outline"
                                className="h-16 text-lg border-2 border-red-200 text-red-700 hover:bg-red-50 flex-1"
                              >
                                <X className="w-6 h-6 mr-3" />
                                Mark All Absent
                              </Button>
                            </div>
                            <p className="text-green-700 mt-3 text-base">
                              💡 Tip: Use "Mark All Present" first, then tap on absent students below
                            </p>
                          </div>

                          {/* Step 3: Individual Student Attendance */}
                          <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-6 rounded-xl mb-8">
                            <h3 className="text-xl font-semibold text-purple-900 mb-6">
                              Step 3: Mark Individual Students
                            </h3>

                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                              {studentsData[selectedClass as keyof typeof studentsData].map((student) => (
                                <Card
                                  key={student.rollNo}
                                  className={`cursor-pointer transition-all duration-200 hover:shadow-lg ${
                                    student.present
                                      ? "bg-gradient-to-r from-green-100 to-emerald-100 border-2 border-green-300 shadow-md"
                                      : "bg-gradient-to-r from-red-100 to-rose-100 border-2 border-red-300 shadow-md"
                                  }`}
                                  onClick={() => toggleAttendance(student.rollNo)}
                                >
                                  <CardContent className="p-6">
                                    <div className="flex items-center justify-between">
                                      <div className="flex items-center space-x-4">
                                        <div
                                          className={`w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg ${
                                            student.present ? "bg-green-600 text-white" : "bg-red-600 text-white"
                                          }`}
                                        >
                                          {student.rollNo}
                                        </div>
                                        <div>
                                          <p className="font-semibold text-lg text-gray-900">{student.name}</p>
                                          <p
                                            className={`text-sm font-medium ${
                                              student.present ? "text-green-700" : "text-red-700"
                                            }`}
                                          >
                                            {student.present ? "✅ Present" : "❌ Absent"}
                                          </p>
                                        </div>
                                      </div>
                                      <div
                                        className={`w-8 h-8 rounded-full flex items-center justify-center ${
                                          student.present ? "bg-green-600" : "bg-red-600"
                                        }`}
                                      >
                                        {student.present ? (
                                          <Check className="w-5 h-5 text-white" />
                                        ) : (
                                          <X className="w-5 h-5 text-white" />
                                        )}
                                      </div>
                                    </div>
                                  </CardContent>
                                </Card>
                              ))}
                            </div>

                            <div className="mt-6 p-4 bg-white rounded-lg border-2 border-gray-200">
                              <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
                                <div className="flex items-center space-x-6 text-lg">
                                  <div className="flex items-center space-x-2">
                                    <div className="w-4 h-4 bg-green-500 rounded-full"></div>
                                    <span className="font-semibold text-green-700">
                                      Present:{" "}
                                      {
                                        studentsData[selectedClass as keyof typeof studentsData].filter(
                                          (s) => s.present,
                                        ).length
                                      }
                                    </span>
                                  </div>
                                  <div className="flex items-center space-x-2">
                                    <div className="w-4 h-4 bg-red-500 rounded-full"></div>
                                    <span className="font-semibold text-red-700">
                                      Absent:{" "}
                                      {
                                        studentsData[selectedClass as keyof typeof studentsData].filter(
                                          (s) => !s.present,
                                        ).length
                                      }
                                    </span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* Step 4: Submit */}
                          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-xl">
                            <h3 className="text-xl font-semibold text-blue-900 mb-4">Step 4: Submit Attendance</h3>
                            <div className="flex flex-col sm:flex-row gap-4 items-center">
                              <Button
                                onClick={handleAttendanceSubmit}
                                className="h-20 text-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-lg hover:shadow-xl transition-all duration-200 px-12"
                                disabled={!selectedPeriod}
                              >
                                <Check className="w-8 h-8 mr-4" />
                                Submit Attendance & Send SMS
                              </Button>
                              <div className="text-center sm:text-left">
                                <p className="text-blue-700 font-medium text-lg">
                                  📱 SMS will be sent to parents of absent students
                                </p>
                                <p className="text-blue-600 text-base">
                                  Make sure all attendance is correct before submitting
                                </p>
                              </div>
                            </div>
                          </div>
                        </>
                      )}
                    </CardContent>
                  </Card>
                </div>
              )}

              {/* View Absentees Page */}
              {currentPage === "absentees" && (
                <div className="space-y-6">
                  <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Eye className="w-5 h-5 text-purple-600" />
                        <span>View Absentees</span>
                      </CardTitle>
                      <CardDescription>Track student absences and SMS notifications</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 lg:gap-6 mb-6">
                        <div className="space-y-2">
                          <Label htmlFor="filter-class" className="text-sm font-medium text-gray-700">
                            Filter by Class
                          </Label>
                          <Select>
                            <SelectTrigger className="h-12 border-gray-200 focus:border-blue-500">
                              <SelectValue placeholder="All classes" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="all">All Classes</SelectItem>
                              {classes.map((cls) => (
                                <SelectItem key={cls} value={cls}>
                                  {cls} Class
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="filter-date" className="text-sm font-medium text-gray-700">
                            Filter by Date
                          </Label>
                          <Input type="date" className="h-12 border-gray-200 focus:border-blue-500" />
                        </div>
                      </div>

                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow className="bg-gradient-to-r from-purple-50 to-pink-50">
                              <TableHead className="font-semibold text-purple-900">Name</TableHead>
                              <TableHead className="font-semibold text-purple-900">Roll No</TableHead>
                              <TableHead className="font-semibold text-purple-900">Date</TableHead>
                              <TableHead className="font-semibold text-purple-900">Class</TableHead>
                              <TableHead className="font-semibold text-purple-900">SMS Status</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {absenteesData.map((absentee, index) => (
                              <TableRow key={index} className={index % 2 === 0 ? "bg-gray-50/50" : "bg-white"}>
                                <TableCell className="font-medium text-gray-900">{absentee.name}</TableCell>
                                <TableCell>
                                  <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                                    <span className="text-purple-700 font-semibold text-sm">{absentee.rollNo}</span>
                                  </div>
                                </TableCell>
                                <TableCell className="text-gray-600">{absentee.date}</TableCell>
                                <TableCell>
                                  <Badge variant="outline" className="border-blue-200 text-blue-700">
                                    {absentee.class}
                                  </Badge>
                                </TableCell>
                                <TableCell>
                                  <Badge
                                    variant={absentee.smsStatus === "Sent" ? "default" : "destructive"}
                                    className={
                                      absentee.smsStatus === "Sent"
                                        ? "bg-green-600 hover:bg-green-700 shadow-sm"
                                        : "bg-red-600 hover:bg-red-700 shadow-sm"
                                    }
                                  >
                                    {absentee.smsStatus === "Sent" ? (
                                      <>
                                        <Check className="w-3 h-3 mr-1" /> Sent
                                      </>
                                    ) : (
                                      <>
                                        <X className="w-3 h-3 mr-1" /> Failed
                                      </>
                                    )}
                                  </Badge>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}
            </main>
          </SidebarInset>
        </SidebarProvider>
      </div>

      {/* Mobile Content */}
      <div className="lg:hidden">
        <main className="p-4">
          {/* Mobile content would go here - same structure as desktop but optimized for mobile */}
          {currentPage === "home" && (
            <div className="space-y-6">
              {/* Mobile Welcome Section */}
              <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 rounded-2xl p-6 text-white">
                <h2 className="text-xl font-bold mb-2">Welcome back, Mrs. Sarah! 👋</h2>
                <p className="text-blue-100 text-sm">Ready to inspire young minds today?</p>
              </div>

              {/* Mobile Stats Grid */}
              <div className="grid grid-cols-2 gap-4">
                <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <UserCheck className="h-5 w-5 text-green-600" />
                      <span className="text-2xl font-bold text-green-700">142</span>
                    </div>
                    <p className="text-sm font-medium text-green-800">Present Today</p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-red-50 to-rose-50 border-red-200">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <UserX className="h-5 w-5 text-red-600" />
                      <span className="text-2xl font-bold text-red-700">8</span>
                    </div>
                    <p className="text-sm font-medium text-red-800">Absent Today</p>
                  </CardContent>
                </Card>
              </div>

              {/* Mobile Quick Actions */}
              <Card className="shadow-lg">
                <CardHeader>
                  <CardTitle className="text-lg">Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button
                    onClick={() => setCurrentPage("attendance")}
                    className="w-full h-12 bg-gradient-to-r from-green-600 to-emerald-600 text-white"
                  >
                    <UserCheck className="w-5 h-5 mr-2" />
                    Take Attendance
                  </Button>
                  <Button onClick={() => setCurrentPage("schedule")} variant="outline" className="w-full h-12">
                    <Calendar className="w-5 h-5 mr-2" />
                    View Schedule
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}
        </main>
      </div>

      {/* SMS Confirmation Modal */}
      <Dialog open={showSMSModal} onOpenChange={setShowSMSModal}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader className="text-center">
            <div className="mx-auto w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mb-4">
              <Check className="w-10 h-10 text-green-600" />
            </div>
            <DialogTitle className="text-2xl font-bold text-green-800">
              Attendance Submitted Successfully! 🎉
            </DialogTitle>
            <DialogDescription className="text-lg mt-4 space-y-2">
              <p className="font-semibold text-gray-700">Great job! Your attendance has been saved.</p>
              <p className="text-base text-gray-600">
                📱 SMS notifications sent to <span className="font-bold text-blue-600">{absentCount}</span> parent
                {absentCount !== 1 ? "s" : ""} about their child's absence.
              </p>
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-center mt-8">
            <Button
              onClick={() => setShowSMSModal(false)}
              className="h-16 text-lg px-12 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white shadow-lg"
            >
              Perfect, Thank You! ✨
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
